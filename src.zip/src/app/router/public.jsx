const publicRoutes = {
  id: "public",
  children: [],
};

export { publicRoutes };
