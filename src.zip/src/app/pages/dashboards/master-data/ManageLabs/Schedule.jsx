import { useState } from 'react';
import { X, Plus } from 'lucide-react';
import { Button, Input } from 'components/ui';
import { toast } from 'sonner';

export default function AddLabUI() {
  const [parameters, setParameters] = useState([
    { id: 1, type: '', frequency: '' },
    { id: 2, type: '', frequency: '' }
  ]);
  const [loading, setLoading] = useState(false);

const addNewParameter = () => {
  const newId = parameters.length > 0 ? Math.max(...parameters.map(p => p.id)) + 1 : 1;
  setParameters([...parameters, { id: newId, type: '', frequency: '' }]);
};

  const removeParameter = (id) => {
    setParameters(parameters.filter(p => p.id !== id));
  };

  const updateParameter = (id, field, value) => {
    setParameters(parameters.map(p =>
      p.id === id ? { ...p, [field]: value } : p
    ));
  };

  const frequencyOptions = [
    'Daily',
    'Weekly', 
    'Bi-weekly',
    'Monthly',
    'Quarterly',
    'Yearly',
    'As needed'
  ];

  const handleSaveSchedule = async () => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(res => setTimeout(res, 1000));
      toast.success("Schedule saved successfully ✅", { duration: 1000 });
    } catch  {
      toast.error("Failed to save schedule ❌");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-semibold text-gray-800">Add Lab</h1>
          <Button
            variant="outline"
            className="text-white bg-blue-600 hover:bg-blue-700"
            onClick={() => console.log('Go back')}
          >
            ← Back to Manage Labs
          </Button>
        </div>
      </div>

      <div className="p-6 max-w-4xl mx-auto">
        {/* Parameters Section */}
       
<div className="bg-white rounded-lg shadow-sm border">
  <div className="p-6 space-y-4">
    {parameters.length > 0 && parameters.map((param) => (
      <div key={param.id} className="flex items-center gap-4">
        <Input
          label="Type"
          placeholder="Type"
          value={param.type}
          onChange={(e) => updateParameter(param.id, 'type', e.target.value)}
          className="flex-1"
        />
        <select
          value={param.frequency}
          onChange={(e) => updateParameter(param.id, 'frequency', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-white"
        >
          <option value="">Frequency</option>
          {frequencyOptions.map(option => (
            <option key={option} value={option}>{option}</option>
          ))}
        </select>
        <Button
          variant="destructive"
          onClick={() => removeParameter(param.id)}
          disabled={parameters.length <= 1}
          className="p-2"
        >
          <X size={16} />
        </Button>
      </div>
    ))}

    {/* Add New Parameter Button */}
    <Button
      onClick={addNewParameter}
      className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
    >
      <Plus size={16} />
      Add New Parameter
    </Button>
  </div>
</div>


        {/* Schedule Navigation */}
        <Button
                color="primary"
                onClick={handleSaveSchedule}
                disabled={loading}
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <svg
                      className="animate-spin h-4 w-4 text-white"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"
                      ></path>
                    </svg>
                    Saving...
                  </div>
                ) : (
                  "Save Schedule"
                )}
              </Button>
      </div>
    </div>
  );
}
