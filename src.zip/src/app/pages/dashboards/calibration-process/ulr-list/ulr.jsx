import { useState } from 'react';

const Button = ({ onClick, className, children, ...props }) => (
  <button
    onClick={onClick}
    className={className}
    {...props}
  >
    {children}
  </button>
);

const ULRList = () => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [showTable, setShowTable] = useState(false);
  const [searchResults, setSearchResults] = useState([]);

  // Sample data for demonstration
  const sampleData = [
    {
      id: 1,
      name: "John Doe",
      idNo: "ID001",
      certificateNo: "CERT001",
      ulrNo: "ULR001",
      customerName: "KALTECH TEST & RESEARCH CENTRE PVT LTD",
      receiveDate: "15/08/2025",
      issueDate: "20/08/2025"
    },
    {
      id: 2,
      name: "Jane Smith",
      idNo: "ID002",
      certificateNo: "CERT002",
      ulrNo: "ULR002",
      customerName: "KALTECH TEST & RESEARCH CENTRE PVT LTD",
      receiveDate: "16/08/2025",
      issueDate: "21/08/2025"
    },
    {
      id: 3,
      name: "Mike Johnson",
      idNo: "ID003",
      certificateNo: "CERT003",
      ulrNo: "ULR003",
      customerName: "KALTECH TEST & RESEARCH CENTRE PVT LTD",
      receiveDate: "17/08/2025",
      issueDate: "22/08/2025"
    }
  ];

  const handleSearch = () => {
    // Validation: Check if all fields are filled
    if (!startDate || !endDate || !selectedCustomer) {
      alert('Please fill in all fields (Start Date, End Date, and Customer) before searching.');
      return;
    }

    // Additional validation: Check if end date is after start date
    if (new Date(endDate) < new Date(startDate)) {
      alert('End date must be after start date.');
      return;
    }

    // If validation passes, show table with results
    console.log('Search clicked:', { startDate, endDate, selectedCustomer });
    setSearchResults(sampleData);
    setShowTable(true);
  };

  return (
    <div className="min-h-screen bg-gray-100" style={{background:"none"}}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" style={{background:"white"}}>
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <h1 className="text-xl font-semibold text-gray-800">ULR List</h1>
          </div>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="p-6">
            {/* First Row - Start Date and End Date */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              {/* Start Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
              </div>

              {/* End Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date
                </label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
              </div>
            </div>

            {/* Second Row - Customer and Search Button */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
              {/* Customer Dropdown */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Customer
                </label>
                <select
                  value={selectedCustomer}
                  onChange={(e) => setSelectedCustomer(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm bg-white"
                >
                  <option value="">Select Customer</option>
                  <option value="KALTECH TEST & RESEARCH CENTRE PVT LTD (7364018482)">KALTECH TEST & RESEARCH CENTRE PVT LTD (7364018482)</option>
                  <option value="ABC CORPORATION (1234567890)">ABC CORPORATION (1234567890)</option>
                  <option value="XYZ INDUSTRIES (9876543210)">XYZ INDUSTRIES (9876543210)</option>
                </select>
              </div>

              {/* Search Button */}
              <div style={{width:"200px"}}>
                <Button
                  onClick={handleSearch}
                  className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-6 py-2 rounded-md text-sm font-medium transition-colors w-full"
                >
                  Search
                </Button>
              </div>
            </div>
          </div>

          {/* Progress Bar Container */}
          <div className="px-6 pb-6">
            <div className="w-full bg-gray-200 rounded-full h-2 relative">
              <div className="bg-blue-500 h-2 rounded-full absolute left-0 top-0" style={{ width: '75%' }}></div>
              {/* Left Arrow */}
              <button className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-4 bg-gray-300 hover:bg-gray-400 rounded-full p-1 transition-colors">
                <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              {/* Right Arrow */}
              <button className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-4 bg-gray-300 hover:bg-gray-400 rounded-full p-1 transition-colors">
                <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Results Table - Only show when search is performed */}
        {showTable && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Search Results</h2>
              
              {/* Table */}
              <div className="overflow-x-auto">
                <table className="min-w-full table-auto border-collapse">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">ID</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Name</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">ID no</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Certificate no</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">ULR No.</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Customer Name</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Receive Date</th>
                      <th className="border border-gray-300 px-4 py-2 text-left text-sm font-medium text-gray-700">Issue Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {searchResults.map((row) => (
                      <tr key={row.id} className="hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.id}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.name}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.idNo}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.certificateNo}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.ulrNo}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.customerName}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.receiveDate}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-gray-700">{row.issueDate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Table Footer with Total Records */}
              <div className="mt-4 flex justify-between items-center text-sm text-gray-600">
                <span>Total Records: {searchResults.length}</span>
                <span>Showing {searchResults.length} results</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ULRList;