// import { useParams, useNavigate } from "react-router";
// import { Button } from "components/ui";
// import { Page } from "components/shared/Page";
// export default function EditModes() {
//   const { id } = useParams();
//   console.log("Editing mode with ID:", id);
//   const navigate = useNavigate();
//   return (
//     <Page title="Edit Mode">
//       <div className="p-6">
//                 {/* ✅ Header + Back Button */}
//         <div className="flex items-center justify-between mb-4">
//           <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
//             Edit Modes
//           </h2>
//           <Button
//             variant="outline"
//             className="text-white bg-blue-600 hover:bg-blue-700"
//             onClick={() => navigate("/dashboards/master-data/modes")}
//           >
//             Back to Modes
//           </Button>
//         </div>
       
//       </div>
//     </Page>
//   );
// }


























import { useParams, useNavigate } from "react-router";
import { Button } from "components/ui";
import { Page } from "components/shared/Page";
import { useState } from "react";

export default function DispatchList() {
  const { id } = useParams();
  const [printLoading, setPrintLoading] = useState(false);

  // const [showApproveModal, setShowApproveModal] = useState(false); // New state for Approve popup
  console.log("Editing mode with ID:", id);
  const navigate = useNavigate();

  const challanData = {
    companyName: "Kaltech Test And Research Centre Pvt. Ltd.",
    address: "Plot No. 141-C, Electronic Complex, Industrial Area, Indore-452010 (MADHYA PRADESH)",
    email: "contact@kalitech.net",
    contactPersonName: "Miss. Nisha Patel",
    contactPersonDesignation: "Manager",
    contactPersonMobile: "0000000000",
    customerName: "KRITI INDUSTRIES (INDIA) LIMITED",
    customerAddress: "Plot No. 75-86, Sector-II, Pithampur-454775, Dist. Dhar (M.P.), Dhar (M.P.)-454775",
    customerContactName: "Miss. Nidhi Patel",
    customerContactDesignation: "-",
    customerContactEmail: "qapthi1@kritindia.co",
    customerContactMobile: "0000000000",
    dispatchDate: "02/06/2022",
    dispatchedThrough: "By Hand",
    dispatchedBy: "Hitesh Agnihotri",
    gstNumber: "23AADCK0799A1ZV",
    challanRef: "KTRC/Challan/0495/02.06.2022",
    items: [
      { name: "Digital Universal Testing Machine N.A Instrument", description: "Instrument", certificateNo: "KTRC2022/0919", invoiceNo: "After Calibration", remark: "Attached certificate, invoice" },
      { name: "KTRC2002/0919 BRN", description: "Instrument", certificateNo: "KTRC2022/0919", invoiceNo: "After Calibration", remark: "Attached certificate, invoice" },
    ],
  };

  const handlePrint = () => {
    setPrintLoading(true);
    setTimeout(() => {
      window.print();
      setPrintLoading(false);
    }, 500);
  };

  // const handleCloseApproveModal = () => {
  //   setShowApproveModal(false);
  // };

  // const handleApproveConfirm = () => {
  //   // Add your approve logic here
  //   console.log("Dispatch approved");
  //   setShowApproveModal(false);
  // };

  return (
    <Page title="View Dispatch Form">
      <div className="p-6">
        {/* Header + Back Button */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <img src="/images/logo.png" alt="Logo" className="h-12 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">
              NON RETURNABLE CHALLAN
            </h2>
          </div>
          <Button
            variant="outline"
            className="text-white bg-blue-600 hover:bg-blue-700"
            onClick={() => navigate("/dashboards/calibration-process/dispatch-list")}
          >
            Back to Dispatch list
          </Button>
        </div>

        {/* Company Details */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-4">
          <div className="flex justify-between">
            <div>
              <h3 className="text-md font-semibold text-gray-700 dark:text-gray-200 mb-2">
                {challanData.companyName}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {challanData.address}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Email: {challanData.email}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 dark:text-gray-400">GST No: {challanData.gstNumber}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Ref: {challanData.challanRef}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Date: {challanData.dispatchDate}</p>
            </div>
          </div>
        </div>

        {/* Customer Details */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-4">
          <h3 className="text-md font-semibold text-gray-700 dark:text-gray-200 mb-2">Customer</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">{challanData.customerName}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Customer Address: {challanData.customerAddress}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Concern Person Name: {challanData.customerContactName}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Concern Person Designation: {challanData.customerContactDesignation}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Concern Person Email: {challanData.customerContactEmail}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Concern Person Mobile: {challanData.customerContactMobile}</p>
        </div>

        {/* Dispatch Details */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-4">
          <div className="flex justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Dispatch Date: {challanData.dispatchDate}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Dispatch Detail: -</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 dark:text-gray-400">Dispatch Through: {challanData.dispatchedThrough}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Dispatched By: {challanData.dispatchedBy}</p>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
          <h3 className="text-md font-semibold text-gray-700 dark:text-gray-200 mb-2">Items</h3>
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th className="px-4 py-2">Name of Item</th>
                <th className="px-4 py-2">Description of Item</th>
                <th className="px-4 py-2">Certificate No</th>
                <th className="px-4 py-2">Invoice No</th>
                <th className="px-4 py-2">Remark</th>
              </tr>
            </thead>
            <tbody>
              {challanData.items.map((item, index) => (
                <tr key={index} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700">
                  <td className="px-4 py-2">{item.name}</td>
                  <td className="px-4 py-2">{item.description}</td>
                  <td className="px-4 py-2">{item.certificateNo}</td>
                  <td className="px-4 py-2">{item.invoiceNo}</td>
                  <td className="px-4 py-2">{item.remark}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Approve Confirmation Modal
        {showApproveModal && (
          <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-auto border border-gray-200">
              <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                <h2 className="text-lg font-semibold text-gray-800">Validate</h2>
                <button
                  onClick={handleCloseApproveModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-6">
                <p className="text-sm font-medium text-gray-700 mb-4">
                  Are you sure you want to Process?
                </p>
              </div>
              <div className="flex justify-end gap-2 p-4 border-t border-gray-200 bg-gray-50">
                <Button
                  onClick={handleApproveConfirm}
                  className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                >
                  OK
                </Button>
                <Button
                  onClick={handleCloseApproveModal}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                >
                  CANCEL
                </Button>
              </div>
            </div>
          </div>
        )} */}
        {/* Download and Approve Buttons */}
        <div className="flex justify-end mt-6 no-print space-x-4">
          <Button onClick={handlePrint} color="success" disabled={printLoading}>
            {printLoading ? (
              <div className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"></path>
                </svg>
                Preparing...
              </div>
            ) : (
              "Download Dispatch Report"
            )}
          </Button>
          {/* <Button
            onClick={() => setShowApproveModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
          >
            Approve
          </Button> */}
        </div>
      </div>
    </Page>
  );
}