import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Page } from "components/shared/Page";
import { Button } from "components/ui";

const ViewDocuments = () => {
    const navigate = useNavigate();
    const { id } = useParams(); // This was missing - extracting id from URL params
    
    // State for pagination and search
    const [currentPage, setCurrentPage] = useState(1);
    const [entriesPerPage, setEntriesPerPage] = useState(25);
    const [searchTerm, setSearchTerm] = useState('');
    
    // Get URL parameters
    const searchParams = new URLSearchParams(window.location.search);
    const caliblocation = searchParams.get("caliblocation") || "Lab";
    const calibacc = searchParams.get("calibacc") || "Nabl";

    // Sample data - replace with actual API call
    const [documents, setDocuments] = useState([
        { id: 1, name: 'PDF', type: 'pdf' },
        { id: 2, name: 'Certificate_001.pdf', type: 'pdf' },
        { id: 3, name: 'Report_002.pdf', type: 'pdf' },
        { id: 4, name: 'Analysis_003.pdf', type: 'pdf' },
        { id: 5, name: 'Calibration_004.pdf', type: 'pdf' },
        // Add more sample data as needed
    ]);

    const totalEntries = 16538; // This should come from your API
    const totalPages = Math.ceil(totalEntries / entriesPerPage);

    // Filter documents based on search term
    const filteredDocuments = documents.filter(doc =>
        doc.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Calculate pagination
    const indexOfLastEntry = currentPage * entriesPerPage;
    const indexOfFirstEntry = indexOfLastEntry - entriesPerPage;
    const currentEntries = filteredDocuments.slice(indexOfFirstEntry, indexOfLastEntry);

    const handleBackToPerformCalibration = () => {
        if (id) {
            navigate(`/dashboards/calibration-process/inward-entry-lab/perform-calibration/${id}?caliblocation=${caliblocation}&calibacc=${calibacc}`);
        } else {
            navigate(-1); // Go back to previous page if id is not available
        }
    };

    const handlePageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    const handleEntriesPerPageChange = (e) => {
        setEntriesPerPage(parseInt(e.target.value));
        setCurrentPage(1); // Reset to first page
    };

    const handleDelete = (docId) => {
        if (window.confirm('Are you sure you want to delete this document?')) {
            // Remove document from state (in real app, make API call first)
            setDocuments(prevDocs => prevDocs.filter(doc => doc.id !== docId));
            console.log('Document deleted:', docId);
            // toast.success('Document deleted successfully');
        }
    };

    const handleView = (docId) => {
        // Open document in new tab or modal
        const doc = documents.find(d => d.id === docId);
        if (doc) {
            // In real app, this would open the actual PDF
            window.open(`/api/documents/${docId}/view`, '_blank');
            console.log('Viewing document:', doc.name);
        }
    };

    const handleDownload = (docId) => {
        // Download document
        const doc = documents.find(d => d.id === docId);
        if (doc) {
            // In real app, this would trigger actual download
            const link = document.createElement('a');
            link.href = `/api/documents/${docId}/download`;
            link.download = doc.name;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            console.log('Downloading document:', doc.name);
            // toast.success('Download started');
        }
    };

    // Generate pagination buttons
    const renderPaginationButtons = () => {
        const buttons = [];
        const maxVisibleButtons = 5;
        
        // Previous button
        buttons.push(
            <Button
                key="previous"
                variant="outline"
                className="px-2 py-1"
                disabled={currentPage === 1}
                onClick={() => handlePageChange(currentPage - 1)}
            >
                Previous
            </Button>
        );

        // Page number buttons
        let startPage = Math.max(1, currentPage - Math.floor(maxVisibleButtons / 2));
        let endPage = Math.min(totalPages, startPage + maxVisibleButtons - 1);

        if (endPage - startPage < maxVisibleButtons - 1) {
            startPage = Math.max(1, endPage - maxVisibleButtons + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            buttons.push(
                <Button
                    key={i}
                    variant="outline"
                    className={`px-2 py-1 ${currentPage === i ? 'bg-blue-500 text-white' : ''}`}
                    onClick={() => handlePageChange(i)}
                >
                    {i}
                </Button>
            );
        }

        // Add ellipsis and last page if needed
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                buttons.push(<span key="ellipsis" className="px-2 py-1">...</span>);
            }
            buttons.push(
                <Button
                    key={totalPages}
                    variant="outline"
                    className="px-2 py-1"
                    onClick={() => handlePageChange(totalPages)}
                >
                    {totalPages}
                </Button>
            );
        }

        // Next button
        buttons.push(
            <Button
                key="next"
                variant="outline"
                className="px-2 py-1"
                disabled={currentPage === totalPages}
                onClick={() => handlePageChange(currentPage + 1)}
            >
                Next
            </Button>
        );

        return buttons;
    };

    return (
        <Page title="View Calibration Document">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
                <div className="flex items-center justify-between p-4 border-b border-gray-200">
                    <h1 className="text-xl font-semibold text-gray-800">View Calibration Document</h1>
                    <Button
                        variant="outline"
                        onClick={handleBackToPerformCalibration}
                        className="bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                    >
                        ← Back to Perform Calibration
                    </Button>
                </div>

                <div className="p-4">
                    <div className="mb-4">
                        <div className="flex justify-between items-center mb-4">
                            <div className="flex items-center gap-2">
                                <span className="text-sm font-medium text-gray-700">Show</span>
                                <select 
                                    className="border border-gray-300 rounded px-2 py-1 text-sm"
                                    value={entriesPerPage}
                                    onChange={handleEntriesPerPageChange}
                                >
                                    <option value={25}>25</option>
                                    <option value={35}>35</option>
                                    <option value={50}>50</option>
                                    <option value={100}>100</option>
                                </select>
                                <span className="text-sm text-gray-600">entries</span>
                            </div>
                            
                            <div className="flex items-center gap-2">
                                <span className="text-sm">Search:</span>
                                <input 
                                    type="text" 
                                    className="border border-gray-300 rounded px-2 py-1 text-sm"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="overflow-x-auto">
                            <table className="w-full text-sm border-collapse">
                                <thead>
                                    <tr className="bg-gray-100">
                                        <th className="p-3 font-medium text-gray-700 border border-gray-300">id</th>
                                        <th className="p-3 font-medium text-gray-700 border border-gray-300">name</th>
                                        <th className="p-3 font-medium text-gray-700 border border-gray-300">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {currentEntries.length > 0 ? (
                                        currentEntries.map((document, index) => (
                                            <tr key={document.id}>
                                                <td className="p-3 border border-gray-200">{indexOfFirstEntry + index + 1}</td>
                                                <td className="p-3 border border-gray-200">
                                                    <div className="flex items-center gap-2">
                                                        <span className="bg-red-500 text-white px-2 py-1 rounded text-xs font-medium">
                                                            PDF
                                                        </span>
                                                        {document.name}
                                                    </div>
                                                </td>
                                                <td className="p-3 border border-gray-200">
                                                    <div className="flex gap-2">
                                                        <button 
                                                            className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-xs font-medium transition-colors"
                                                            onClick={() => handleDelete(document.id)}
                                                        >
                                                            delete
                                                        </button>
                                                        <button 
                                                            className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-xs font-medium transition-colors"
                                                            onClick={() => handleView(document.id)}
                                                        >
                                                            View
                                                        </button>
                                                        <button 
                                                            className="bg-orange-500 hover:bg-orange-600 text-white px-3 py-1 rounded text-xs font-medium transition-colors"
                                                            onClick={() => handleDownload(document.id)}
                                                        >
                                                            Download
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="3" className="p-8 text-center text-gray-500">
                                                No documents found
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>

                        <div className="flex justify-between items-center mt-4 text-sm text-gray-600">
                            <div>
                                Showing {indexOfFirstEntry + 1} to {Math.min(indexOfLastEntry, filteredDocuments.length)} of {totalEntries} entries
                            </div>
                            <div className="flex gap-1">
                                {renderPaginationButtons()}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Page>
    );
};

export default ViewDocuments;