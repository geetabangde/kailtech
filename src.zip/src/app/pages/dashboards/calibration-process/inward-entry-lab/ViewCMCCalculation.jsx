// import { useParams, useNavigate } from "react-router";
// import { useEffect, useState } from "react";
// import { Page } from "components/shared/Page";
// import { Button } from "components/ui";
// import axios from "utils/axios";
// import { toast } from "sonner";

// export default function ViewInwardEntrySrf() {
//   const { id: inwardId, itemId: instId } = useParams();
//   console.log(inwardId, instId);

//   const navigate = useNavigate();
//   const searchParams = new URLSearchParams(window.location.search);
//   const caliblocation = searchParams.get("caliblocation") || "Lab";
//   const calibacc = searchParams.get("calibacc") || "Nabl";

//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [printLoading, setPrintLoading] = useState(false);

//   const handleBackToPerformCalibration = () => {
//     navigate(
//       `/dashboards/calibration-process/inward-entry-lab/perform-calibration/${inwardId}?caliblocation=${caliblocation}&calibacc=${calibacc}`
//     );
//   };

//   const handleBackToInwardList = () => {
//     navigate(
//       `/dashboards/calibration-process/inward-entry-lab?caliblocation=${caliblocation}&calibacc=${calibacc}`
//     );
//   };

//   useEffect(() => {
//     const fetchUncertainty = async () => {
//       try {
//         const response = await axios.get(
//           `/calibrationprocess/get-uncertainty?inwardid=${inwardId}&instid=${instId}&caliblocation=${caliblocation}&calibacc=${calibacc}`
//         );

//         console.log("API Response:", response.data);
//         const suffix = response.data.data?.listInstrument?.suffix || "";
// console.log("Instrument Suffix:", suffix);
//         if (response.data?.status === true) {
//           console.log(response.data.data?.listInstrument.uncertaintytable);
//           const apiData = response.data.data?.uncertainty || [];
//           const mappedData = apiData.map((item) => ({
//             srNo: item.sr_no,
//             typeOfMeasurement: item.type_of_measurement,
//             values: [item.uuc_0, item.uuc_1, item.uuc_2, item.uuc_3, item.uuc_4],
//             unit: item.unit,
//             calibrationPoint: item.calibration_point,
//             average: item.average_uuc,
//             stdDeviation: item.std_deviation,
//             typeA: item.type_a,
//             uncertaintyOfMaster: item.master_uncertainty , 
//             leastCount: item.least_count_uuc ,
//             thermalCoeffMaster: item.thermal_coeff_master , 
//             thermalCoeffUuc: item.thermal_coeff_uuc , 
//             uncTempDevice: item.uncertainty_temp_device,
//             stdUncTher20: item.std_unc_thermal_coeff,
//             stdUncDiff: item.std_unc_diff_temp,
//             uncError: item.uncertainty_error ,
//             combinedUnc: item.combined_uncertainty,
//             dof: item.degrees_of_freedom,
//             coverageFactor: item.coverage_factor,
//             expandedUnc: item.expanded_uncertainty,
//             cmc: item.cmc_uncertainty,
//           }));

//           setData(mappedData);
//         } else {
//           toast.error("No data found");
//           setData([]);
//         }
//       } catch (error) {
//         console.error("Error fetching uncertainty:", error);
//         toast.error("Failed to fetch data");
//         setData([]);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchUncertainty();
//   }, [inwardId, instId, caliblocation, calibacc]);

//   const handlePrint = () => {
//     setPrintLoading(true);
//     setTimeout(() => {
//       window.print();
//       setPrintLoading(false);
//     }, 1000); // Simulate preparation delay
//   };

//   return (
//     <Page title="View Inward Entry SRF">
//       <div className="p-6 bg-gray-50 min-h-screen">
//         <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-white rounded-lg shadow-sm mb-6">
//           <h1 className="text-2xl font-semibold text-gray-800">Uncertainty Calculation</h1>
//           <div className="space-x-2">
//             <Button
//               variant="outline"
//               onClick={handleBackToInwardList}
//               className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
//             >
//               &lt;&lt; Back to Inward Entry List
//             </Button>
//             <Button
//               variant="outline"
//               onClick={handleBackToPerformCalibration}
//               className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
//             >
//               &lt;&lt; Back to Perform Calibration
//             </Button>
//           </div>
//         </div>

//         {loading ? (
//           <div className="flex h-[60vh] items-center justify-center text-gray-600">
//             <svg className="animate-spin h-6 w-6 mr-2 text-blue-600" viewBox="0 0 24 24">
//               <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
//               <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"></path>
//             </svg>
//             Loading CMS Calculation...
//           </div>
//         ) : data.length === 0 ? (
//           <div className="flex h-[60vh] items-center justify-center text-gray-600">
//             <p>No data available</p>
//           </div>
//         ) : (
//           <div className="overflow-x-auto bg-white rounded-lg shadow-md">
            
//               <table className="w-full border-collapse text-xs text-gray-700">
//               <thead>
//                 <tr className="bg-gray-100 text-center">
//                   <th colSpan="11" className="border border-gray-300 px-2 py-2 bg-gray-200 font-semibold">
//                     Type A Factor
//                   </th>
//                   <th colSpan="3" className="border border-gray-300 px-2 py-2 bg-gray-200 font-semibold">
//                     Type B Factor
//                   </th>
//                   <th colSpan="5" className="border border-gray-300 px-2 py-2 bg-gray-200 font-semibold">
//                     Uncertainty Measurement
//                   </th>
//                 </tr>
//                 <tr className="bg-gray-200 text-center text-xs font-medium">
//                   <th className="border border-gray-300 px-2 py-2">Sr No</th>
//                   <th className="border border-gray-300 px-2 py-2">Type Of Measurement</th>
//                   <th className="border border-gray-300 px-2 py-2">1</th>
//                   <th className="border border-gray-300 px-2 py-2">2</th>
//                   <th className="border border-gray-300 px-2 py-2">3</th>
//                   <th className="border border-gray-300 px-2 py-2">4</th>
//                   <th className="border border-gray-300 px-2 py-2">5</th>
//                   <th className="border border-gray-300 px-2 py-2">Unit</th>
//                   <th className="border border-gray-300 px-2 py-2">Calibration Point</th>
//                   <th className="border border-gray-300 px-2 py-2">Average</th>
//                   <th className="border border-gray-300 px-2 py-2">Std Deviation</th>
//                   <th className="border border-gray-300 px-2 py-2">Type A</th>
//                   <th className="border border-gray-300 px-2 py-2">Uncertainty of Master in mm</th>
//                   <th className="border border-gray-300 px-2 py-2">Least Count of UUC</th>
//                   <th className="border border-gray-300 px-2 py-2">Thermal Coefficient of Master</th>
//                   <th className="border border-gray-300 px-2 py-2">Thermal Coefficient of UUC</th>
//                   <th className="border border-gray-300 px-2 py-2">Uncertainty due to Temperature Indicating Device (mm)</th>
//                   <th className="border border-gray-300 px-2 py-2">Standard uncertainty due to the thermal coefficient of expansion master and Unit Under Calibration assuming 20% (mm)</th>
//                   <th className="border border-gray-300 px-2 py-2">Standard uncertainty due to the difference in temperature master and Unit Under Calibration assuming 0.5°C (mm)</th>
//                   <th className="border border-gray-300 px-2 py-2">Standard uncertainty due to Error in Master (Taken Half) in mm</th>
//                   <th className="border border-gray-300 px-2 py-2">Combined Uncertainty</th>
//                   <th className="border border-gray-300 px-2 py-2">Degree of Freedom</th>
//                   <th className="border border-gray-300 px-2 py-2">Coverage Factor (k)</th>
//                   <th className="border border-gray-300 px-2 py-2">Expanded Uncertainty in Value</th>
//                   <th className="border border-gray-300 px-2 py-2">CMC taken</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {data.map((row, i) => (
//                   <tr key={i} className="hover:bg-gray-50">
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.srNo}</td>
//                     <td className="border border-gray-300 px-2 py-3">{row.typeOfMeasurement}</td>
//                     {row.values.map((v, idx) => (
//                       <td key={idx} className="border border-gray-300 px-2 py-3 text-center">
//                         {v}
//                       </td>
//                     ))}
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.unit}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.calibrationPoint}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.average}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.stdDeviation}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.typeA}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.uncertaintyOfMaster}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.leastCount}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.thermalCoeffMaster}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.thermalCoeffUuc}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.uncTempDevice}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.stdUncTher20}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.stdUncDiff}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.uncError}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.combinedUnc}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.dof}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.coverageFactor}</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.expandedUnc} μm</td>
//                     <td className="border border-gray-300 px-2 py-3 text-center">{row.cmc}</td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>

            
      
            
//           </div>
//         )}

//         <div className="mt-6 flex justify-end">
//           <Button
//             onClick={handlePrint}
//             className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
//           >
//             {printLoading ? (
//               <div className="flex items-center gap-2">
//                 <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
//                   <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
//                   <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"></path>
//                 </svg>
//                 Preparing...
//               </div>
//             ) : (
//               "Download CRF"
//             )}
//           </Button>
//         </div>
//       </div>
//     </Page>
//   );
// }
import { useParams, useNavigate } from "react-router";
import { useEffect, useState } from "react";
import { Page } from "components/shared/Page";
import { Button } from "components/ui";
import axios from "utils/axios";
import { toast } from "sonner";

// Table configurations for different instrument types
const tableConfigurations = {
  ctg: {
    headers: {
      typeA: { colSpan: 11, title: "Type A Factor" },
      typeB: { colSpan: 3, title: "Type B Factor" },
      uncertainty: { colSpan: 5, title: "Uncertainty Measurement" }
    },
    columns: [
      { key: "srNo", label: "Sr No", width: "px-2" },
      { key: "typeOfMeasurement", label: "Type Of Measurement", width: "px-2" },
      { key: "value1", label: "1", width: "px-2" },
      { key: "value2", label: "2", width: "px-2" },
      { key: "value3", label: "3", width: "px-2" },
      { key: "value4", label: "4", width: "px-2" },
      { key: "value5", label: "5", width: "px-2" },
      { key: "unit", label: "Unit", width: "px-2" },
      { key: "calibrationPoint", label: "Calibration Point", width: "px-2" },
      { key: "average", label: "Average", width: "px-2" },
      { key: "stdDeviation", label: "Std Deviation", width: "px-2" },
      { key: "typeA", label: "Type A", width: "px-2" },
      { key: "uncertaintyOfMaster", label: "Uncertainty of Master in mm", width: "px-2" },
      { key: "leastCount", label: "Least Count of UUC", width: "px-2" },
      { key: "thermalCoeffMaster", label: "Thermal Coefficient of Master", width: "px-2" },
      { key: "thermalCoeffUuc", label: "Thermal Coefficient of UUC", width: "px-2" },
      { key: "uncTempDevice", label: "Uncertainty due to Temperature Indicating Device (mm)", width: "px-2" },
      { key: "stdUncTher20", label: "Standard uncertainty due to the thermal coefficient of expansion master and Unit Under Calibration assuming 20% (mm)", width: "px-2" },
      { key: "stdUncDiff", label: "Standard uncertainty due to the difference in temperature master and Unit Under Calibration assuming 0.5°C (mm)", width: "px-2" },
      { key: "uncError", label: "Standard uncertainty due to Error in Master (Taken Half) in mm", width: "px-2" },
      { key: "combinedUnc", label: "Combined Uncertainty", width: "px-2" },
      { key: "dof", label: "Degree of Freedom", width: "px-2" },
      { key: "coverageFactor", label: "Coverage Factor (k)", width: "px-2" },
      { key: "expandedUnc", label: "Expanded Uncertainty in Value", width: "px-2", suffix: "μm" },
      { key: "cmc", label: "CMC taken", width: "px-2" }
    ]
  },
  
  odfm: {
    headers: {
      typeA: { colSpan: 11, title: "Type A Factor" },
      typeB: { colSpan: 3, title: "Type B Factor" },
      uncertainty: { colSpan: 5, title: "Uncertainty Measurement" }
    },
    columns: [
      { key: "srNo", label: "Sr no", width: "px-2" },
      { key: "value1", label: "1", width: "px-2" },
      { key: "value2", label: "2", width: "px-2" },
      { key: "value3", label: "3", width: "px-2" },
      { key: "value4", label: "4", width: "px-2" },
      { key: "value5", label: "5", width: "px-2" },
      { key: "unit", label: "Unit", width: "px-2" },
      { key: "calibrationPoint", label: "Calibration point", width: "px-2" },
      { key: "average", label: "Average", width: "px-2" },
      { key: "stdDeviation", label: "Std Deviation", width: "px-2" },
      { key: "typeA", label: "Type A", width: "px-2" },
      { key: "uncertaintyMaster1", label: "Uncertainty of master 1 sensor in (°C)", width: "px-2" },
      { key: "uncertaintyMaster2Value", label: "Uncertainty of master 2 (6.5 DMM) in Value", width: "px-2" },
      { key: "sensitivityCoeff", label: "Sensitivity Coefficent", width: "px-2" },
      { key: "uncertaintyMaster2Temp", label: "Uncertainty of master 2 (6.5 DMM) in °C", width: "px-2" },
      { key: "bathStability", label: "Stability of Bath (°C)", width: "px-2" },
      { key: "bathUniformity", label: "Uniformity Of Bath (°C)", width: "px-2" },
      { key: "masterDrift", label: "Drift in Master (°C)", width: "px-2" },
      { key: "leastCount", label: "Least Count of UUC", width: "px-2" },
      { key: "combinedUnc", label: "Combined Uncertainty", width: "px-2" },
      { key: "dof", label: "Degree of Freedom", width: "px-2" },
      { key: "coverageFactor", label: "Coverage Factor (k)", width: "px-2" },
      { key: "expandedUnc", label: "Expanded Uncertainty in Value", width: "px-2" },
      { key: "cmc", label: "cmctaken", width: "px-2" }
    ]
  },

  dpg: {
    headers: {
      typeA: { colSpan: 11, title: "Type A Factor" },
      typeB: { colSpan: 8, title: "Type B Factor" },
      uncertainty: { colSpan: 4, title: "Uncertainty Measurement" }
    },
    columns: [
      { key: "srNo", label: "Sr No", width: "px-2" },
      { key: "typeOfMeasurement", label: "Type Of Measurement", width: "px-2" },
      { key: "value1", label: "1", width: "px-2" },
      { key: "value2", label: "2", width: "px-2" },
      { key: "value3", label: "3", width: "px-2" },
      { key: "value4", label: "4", width: "px-2" },
      { key: "value5", label: "5", width: "px-2" },
      { key: "unit", label: "Unit", width: "px-2" },
      { key: "calibrationPoint", label: "Calibration Point", width: "px-2" },
      { key: "average", label: "Average", width: "px-2" },
      { key: "stdDeviation", label: "Std Deviation", width: "px-2" },
      { key: "typeA", label: "Type A", width: "px-2" },
      { key: "uncertaintyOfMaster", label: "Uncertainty of Master", width: "px-2" },
      { key: "leastCount", label: "Least Count", width: "px-2" },
      { key: "temperatureEffect", label: "Temperature Effect", width: "px-2" },
      { key: "pressureStability", label: "Pressure Stability", width: "px-2" },
      { key: "hysteresis", label: "Hysteresis", width: "px-2" },
      { key: "repeatability", label: "Repeatability", width: "px-2" },
      { key: "drift", label: "Drift", width: "px-2" },
      { key: "combinedUnc", label: "Combined Uncertainty", width: "px-2" },
      { key: "dof", label: "Degree of Freedom", width: "px-2" },
      { key: "coverageFactor", label: "Coverage Factor (k)", width: "px-2" },
      { key: "expandedUnc", label: "Expanded Uncertainty", width: "px-2" }
    ]
  },

  apg: {
    headers: {
      typeA: { colSpan: 11, title: "Type A Factor" },
      typeB: { colSpan: 6, title: "Type B Factor" },
      uncertainty: { colSpan: 4, title: "Uncertainty Measurement" }
    },
    columns: [
      { key: "srNo", label: "Sr No", width: "px-2" },
      { key: "typeOfMeasurement", label: "Type Of Measurement", width: "px-2" },
      { key: "value1", label: "1", width: "px-2" },
      { key: "value2", label: "2", width: "px-2" },
      { key: "value3", label: "3", width: "px-2" },
      { key: "value4", label: "4", width: "px-2" },
      { key: "value5", label: "5", width: "px-2" },
      { key: "unit", label: "Unit", width: "px-2" },
      { key: "calibrationPoint", label: "Calibration Point", width: "px-2" },
      { key: "average", label: "Average", width: "px-2" },
      { key: "stdDeviation", label: "Std Deviation", width: "px-2" },
      { key: "typeA", label: "Type A", width: "px-2" },
      { key: "uncertaintyOfMaster", label: "Uncertainty of Master", width: "px-2" },
      { key: "leastCount", label: "Least Count", width: "px-2" },
      { key: "temperatureEffect", label: "Temperature Effect", width: "px-2" },
      { key: "pressureStability", label: "Pressure Stability", width: "px-2" },
      { key: "linearity", label: "Linearity", width: "px-2" },
      { key: "combinedUnc", label: "Combined Uncertainty", width: "px-2" },
      { key: "dof", label: "Degree of Freedom", width: "px-2" },
      { key: "coverageFactor", label: "Coverage Factor (k)", width: "px-2" },
      { key: "expandedUnc", label: "Expanded Uncertainty", width: "px-2" }
    ]
  }
};

// Data mapping function for different instrument types
const mapApiDataToTableFormat = (apiData, suffix) => {
  const baseMapping = {
    srNo: apiData.sr_no,
    typeOfMeasurement: apiData.type_of_measurement,
    values: [apiData.uuc_0, apiData.uuc_1, apiData.uuc_2, apiData.uuc_3, apiData.uuc_4],
    value1: apiData.uuc_0,
    value2: apiData.uuc_1,
    value3: apiData.uuc_2,
    value4: apiData.uuc_3,
    value5: apiData.uuc_4,
    unit: apiData.unit,
    calibrationPoint: apiData.calibration_point,
    average: apiData.average_uuc,
    stdDeviation: apiData.std_deviation,
    typeA: apiData.type_a,
    combinedUnc: apiData.combined_uncertainty,
    dof: apiData.degrees_of_freedom,
    coverageFactor: apiData.coverage_factor,
    expandedUnc: apiData.expanded_uncertainty,
    cmc: apiData.cmc_uncertainty,
  };

  // Add suffix-specific mappings
  switch (suffix) {
    case 'ctg':
      return {
        ...baseMapping,
        uncertaintyOfMaster: apiData.master_uncertainty,
        leastCount: apiData.least_count_uuc,
        thermalCoeffMaster: apiData.thermal_coeff_master,
        thermalCoeffUuc: apiData.thermal_coeff_uuc,
        uncTempDevice: apiData.uncertainty_temp_device,
        stdUncTher20: apiData.std_unc_thermal_coeff,
        stdUncDiff: apiData.std_unc_diff_temp,
        uncError: apiData.uncertainty_error,
      };
    
    case 'odfm':
      return {
        ...baseMapping,
        uncertaintyMaster1: apiData.uncertainty_master_1,
        uncertaintyMaster2Value: apiData.uncertainty_master_2_value,
        sensitivityCoeff: apiData.sensitivity_coefficient,
        uncertaintyMaster2Temp: apiData.uncertainty_master_2_temp,
        bathStability: apiData.bath_stability,
        bathUniformity: apiData.bath_uniformity,
        masterDrift: apiData.master_drift,
        leastCount: apiData.least_count_uuc,
      };
    
    case 'dpg':
      return {
        ...baseMapping,
        uncertaintyOfMaster: apiData.master_uncertainty,
        leastCount: apiData.least_count_uuc,
        temperatureEffect: apiData.temperature_effect,
        pressureStability: apiData.pressure_stability,
        hysteresis: apiData.hysteresis,
        repeatability: apiData.repeatability,
        drift: apiData.drift,
      };
    
    case 'apg':
      return {
        ...baseMapping,
        uncertaintyOfMaster: apiData.master_uncertainty,
        leastCount: apiData.least_count_uuc,
        temperatureEffect: apiData.temperature_effect,
        pressureStability: apiData.pressure_stability,
        linearity: apiData.linearity,
      };
    
    default:
      return baseMapping;
  }
};

// Table rendering component
const UncertaintyTable = ({ data, suffix }) => {
  const config = tableConfigurations[suffix];
  
  if (!config) {
    return <div className="text-red-500">Unsupported instrument type: {suffix}</div>;
  }

  return (
    <div className="overflow-x-auto bg-white rounded-lg shadow-md">
      <table className="w-full border-collapse text-xs text-gray-700">
        <thead>
          <tr className="bg-gray-100 text-center">
            {config.headers.typeA && (
              <th colSpan={config.headers.typeA.colSpan} className="border border-gray-300 px-2 py-2 bg-gray-200 font-semibold">
                {config.headers.typeA.title}
              </th>
            )}
            {config.headers.typeB && (
              <th colSpan={config.headers.typeB.colSpan} className="border border-gray-300 px-2 py-2 bg-gray-200 font-semibold">
                {config.headers.typeB.title}
              </th>
            )}
            {config.headers.uncertainty && (
              <th colSpan={config.headers.uncertainty.colSpan} className="border border-gray-300 px-2 py-2 bg-gray-200 font-semibold">
                {config.headers.uncertainty.title}
              </th>
            )}
          </tr>
          <tr className="bg-gray-200 text-center text-xs font-medium">
            {config.columns.map((col, index) => (
              <th key={index} className={`border border-gray-300 ${col.width} py-2`}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i} className="hover:bg-gray-50">
              {config.columns.map((col, index) => (
                <td key={index} className={`border border-gray-300 ${col.width} py-3 text-center`}>
                  {row[col.key]}{col.suffix || ''}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default function ViewInwardEntrySrf() {
  const { id: inwardId, itemId: instId } = useParams();
  console.log(inwardId, instId);

  const navigate = useNavigate();
  const searchParams = new URLSearchParams(window.location.search);
  const caliblocation = searchParams.get("caliblocation") || "Lab";
  const calibacc = searchParams.get("calibacc") || "Nabl";

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [printLoading, setPrintLoading] = useState(false);
  const [instrumentSuffix, setInstrumentSuffix] = useState('');

  const handleBackToPerformCalibration = () => {
    navigate(
      `/dashboards/calibration-process/inward-entry-lab/perform-calibration/${inwardId}?caliblocation=${caliblocation}&calibacc=${calibacc}`
    );
  };

  const handleBackToInwardList = () => {
    navigate(
      `/dashboards/calibration-process/inward-entry-lab?caliblocation=${caliblocation}&calibacc=${calibacc}`
    );
  };

  useEffect(() => {
    const fetchUncertainty = async () => {
      try {
        const response = await axios.get(
          `/calibrationprocess/get-uncertainty?inwardid=${inwardId}&instid=${instId}&caliblocation=${caliblocation}&calibacc=${calibacc}`
        );

        console.log("API Response:", response.data);
        const suffix = response.data.data?.listInstrument?.suffix || "";
        console.log("Instrument Suffix:", suffix);
        setInstrumentSuffix(suffix);

        if (response.data?.status === true) {
          console.log(response.data.data?.listInstrument.uncertaintytable);
          const apiData = response.data.data?.uncertainty || [];
          const mappedData = apiData.map((item) => mapApiDataToTableFormat(item, suffix));
          setData(mappedData);
        } else {
          toast.error("No data found");
          setData([]);
        }
      } catch (error) {
        console.error("Error fetching uncertainty:", error);
        toast.error("Failed to fetch data");
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchUncertainty();
  }, [inwardId, instId, caliblocation, calibacc]);

  const handlePrint = () => {
    setPrintLoading(true);
    setTimeout(() => {
      window.print();
      setPrintLoading(false);
    }, 1000);
  };

  return (
    <Page title="View Inward Entry SRF">
      <div className="p-6 bg-gray-50 min-h-screen">
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-white rounded-lg shadow-sm mb-6">
          <h1 className="text-2xl font-semibold text-gray-800">
            Uncertainty Calculation {instrumentSuffix && `(${instrumentSuffix.toUpperCase()})`}
          </h1>
          <div className="space-x-2">
            <Button
              variant="outline"
              onClick={handleBackToInwardList}
              className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
            >
              &lt;&lt; Back to Inward Entry List
            </Button>
            <Button
              variant="outline"
              onClick={handleBackToPerformCalibration}
              className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
            >
              &lt;&lt; Back to Perform Calibration
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex h-[60vh] items-center justify-center text-gray-600">
            <svg className="animate-spin h-6 w-6 mr-2 text-blue-600" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"></path>
            </svg>
            Loading CMS Calculation...
          </div>
        ) : data.length === 0 ? (
          <div className="flex h-[60vh] items-center justify-center text-gray-600">
            <p>No data available</p>
          </div>
        ) : (
          <UncertaintyTable data={data} suffix={instrumentSuffix} />
        )}

        <div className="mt-6 flex justify-end">
          <Button
            onClick={handlePrint}
            className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
          >
            {printLoading ? (
              <div className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"></path>
                </svg>
                Preparing...
              </div>
            ) : (
              "Download CRF"
            )}
          </Button>
        </div>
      </div>
    </Page>
  );
}