import {
  Menu,
  MenuButton,
  MenuItem,
  MenuItems,
  Transition,
} from "@headlessui/react";
import {
  EllipsisHorizontalIcon,
  PencilIcon,
} from "@heroicons/react/24/outline";
import clsx from "clsx";
import { Fragment, useCallback, useState } from "react";
import PropTypes from "prop-types";
import { ConfirmModal } from "components/shared/ConfirmModal";
import { Button } from "components/ui";
import axios from "utils/axios";
import { toast } from "sonner";
import { useNavigate, useLocation } from "react-router";

// ----------------------------------------------------------------------

const confirmMessages = {
  pending: {
    description:
      "Are you sure you want to delete this Inward Entry? Once deleted, it cannot be restored.",
  },
  success: {
    title: "Inward Entry operation deleted",
  },
};

export function RowActions({ row, table }) {
  const navigate = useNavigate();
  const location = useLocation();

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [confirmDeleteLoading, setConfirmDeleteLoading] = useState(false);
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [deleteError, setDeleteError] = useState(false);

  // Convert localStorage string to array of numbers
  const permissions =
    localStorage.getItem("userPermissions")?.split(",").map(Number) || [];

  // console.log("User permissions:", permissions);

  const closeModal = () => {
    setDeleteModalOpen(false);
  };

  const handleDeleteRows = useCallback(async () => {
    const id = row.original.id;
    // const status = row.original.status;
    const params = new URLSearchParams(location.search);
    const caliblocation =
      params.get("caliblocation") || row.original.caliblocation || "Lab";
    const calibacc =
      params.get("calibacc") || row.original.calibacc || "Nabl";

    setConfirmDeleteLoading(true);

    try {
      await axios.delete(
        `/calibrationoperations/calibration-method-destroy/${id}?caliblocation=${encodeURIComponent(
          caliblocation
        )}&calibacc=${encodeURIComponent(calibacc)}`
      );
      table.options.meta?.deleteRow(row);
      setDeleteSuccess(true);
      toast.success("Calibration operation deleted ✅", {
        duration: 1000,
        icon: "🗑️",
      });
    } catch (error) {
      console.error("Delete failed:", error);
      setDeleteError(true);
      toast.error("Failed to delete calibration operation ❌", {
        duration: 2000,
      });
    } finally {
      setConfirmDeleteLoading(false);
    }
  }, [row, table, location.search]);

  const state = deleteError ? "error" : deleteSuccess ? "success" : "pending";

  const getNavigationUrl = (path) => {
    const params = new URLSearchParams(location.search);
    const caliblocation =
      params.get("caliblocation") || row.original.caliblocation || "Lab";
    const calibacc =
      params.get("calibacc") || row.original.calibacc || "Nabl";
    return `${path}?caliblocation=${encodeURIComponent(
      caliblocation
    )}&calibacc=${encodeURIComponent(calibacc)}`;
  };

  // Actions list with permission property
  const actions = [
    // Conditionally include "Add Inward Item" based on status
    ...(row.original.status === -1
      ? [
          {
            label: "Add Inward Item",
            permission: 98,
            onClick: () =>
              navigate(
                getNavigationUrl(
                  `/dashboards/calibration-process/inward-entry-lab/add-inward-item/${row.original.id}`
                )
              ),
          },
        ]
      : []),
       ...(row.original.status === 4 || row.original.status === 5 || row.original.status === 11
      ? [
    {
      label: "Edit CRF Entry Detail",
     
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-inward-entry/${row.original.id}`
          )
        ),
    },
     ]
      : []),
       ...(row.original.status === 0
      ? [
    {
      label: "Review Inward",
       permission:99,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/review-inward/${row.original.id}`
          )
        ),
    },
       ]
      : []),
       ...(row.original.status === 1
      ? [
     {
      label: "Technical Acceptance",
      permission:100,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/technical-acceptance/${row.original.id}`
          )
        ),
    },
       ]
      : []),
 ...(row.original.status === 2
      ? [
         {
      label: "Edit Bd Person",
      permission: 101,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-bd-person/${row.original.id}`
          )
        ),
    },
      
     ]
      : []),
       ...(row.original.status === 4
      ? [
       {
      label: "Perform Calibration",
      permission:97,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/perform-calibration/${row.original.id}`
          )
        ),
    },
     ]
      : []),
      
       {
      label: "Edit Bd Person",
      permission:406,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-bd-person/${row.original.id}`
          )
        ),
    },
      ...(row.original.status ===2
      ? [
   {
      label: "Transfer In lab",
      // permission:101,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/sample-transfer-in-lab/${row.original.id}`
          )
        ),
    },
     ]
      : []),
    {
      label: "SRF View",
      permission: 372,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/srf-view/${row.original.id}`
          )
        ),
    },
    {
      label: "CRF View",
      permission: 373,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/crf-view/${row.original.id}`
          )
        ),
    },
    {
      label: "Edit Work Order detail",
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-work-order/${row.original.id}`
          )
        ),
    },
    {
      label: "Edit Customer Responsible for payment",
      permission: 297,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-customer/${row.original.id}`
          )
        ),
    },
    {
      label: "Edit Billing Detail",
      permission: 407,
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-billing/${row.original.id}`
          )
        ),
    },
       {
      label: "Fill Feedback form",
   
      onClick: () =>
        navigate(
          getNavigationUrl(
            `/dashboards/calibration-process/inward-entry-lab/edit-billing/${row.original.id}`
          )
        ),
    },
   
    
   
  ];

  // Filter actions based on permission (if defined)
  const filteredActions = actions.filter(
    (action) =>
      !action.permission || permissions.includes(action.permission)
  );

  return (
    <>
      <div className="flex justify-center space-x-1.5">
        <Menu as="div" className="relative inline-block text-left">
          <MenuButton as={Button} isIcon className="size-8 rounded-full">
            <EllipsisHorizontalIcon className="size-4.5" />
          </MenuButton>

          <Transition
            as={Fragment}
            enter="transition ease-out"
            enterFrom="opacity-0 translate-y-2"
            enterTo="opacity-100 translate-y-0"
            leave="transition ease-in"
            leaveFrom="opacity-100 translate-y-0"
            leaveTo="opacity-0 translate-y-2"
          >
            <MenuItems
              anchor={{ to: "bottom end", gap: 12 }}
              className="absolute z-50 w-56 rounded-lg border border-gray-300 bg-white py-1 shadow-lg shadow-gray-200/50 dark:border-dark-500 dark:bg-dark-750 dark:shadow-none"
            >
              {filteredActions.map((action) => (
                <MenuItem key={action.label}>
                  {({ focus }) => (
                    <button
                      onClick={action.onClick}
                      className={clsx(
                        "flex h-9 w-full items-center space-x-3 px-3 tracking-wide outline-none transition-colors",
                        focus
                          ? "bg-gray-100 text-gray-800 dark:bg-dark-600 dark:text-dark-100"
                          : ""
                      )}
                    >
                      <PencilIcon className="size-4.5 stroke-1" />
                      <span>{action.label}</span>
                    </button>
                  )}
                </MenuItem>
              ))}
            </MenuItems>
          </Transition>
        </Menu>
      </div>

      <ConfirmModal
        show={deleteModalOpen}
        onClose={closeModal}
        messages={confirmMessages}
        onOk={handleDeleteRows}
        confirmLoading={confirmDeleteLoading}
        state={state}
      />
    </>
  );
}

RowActions.propTypes = {
  row: PropTypes.object,
  table: PropTypes.object,
};