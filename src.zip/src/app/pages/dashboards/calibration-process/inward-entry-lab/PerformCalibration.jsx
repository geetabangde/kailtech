import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button, Select, Pagination, PaginationItems, PaginationNext, PaginationPrevious } from "components/ui";
import axios from "utils/axios";
import { toast } from "sonner";
import { PerformActions } from "./PerformActions";

const PerformCalibration = () => {
    const navigate = useNavigate();

    // Extract ID from URL path
    const pathParts = window.location.pathname.split("/");
    const inwardId = pathParts[pathParts.length - 1];

    // Get URL parameters
    const searchParams = new URLSearchParams(window.location.search);
    const caliblocation = searchParams.get("caliblocation") || "Lab";
    const calibacc = searchParams.get("calibacc") || "Nabl";

    const [searchTerm, setSearchTerm] = useState('');
    const [pageSize, setPageSize] = useState(10);
    const [loading, setLoading] = useState(false);
    const [calibrationData, setCalibrationData] = useState([]);
    const [selectedItems, setSelectedItems] = useState([]);
    const [selectAll, setSelectAll] = useState(false);
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
    const [currentPage, setCurrentPage] = useState(1);
    const [reviewers, setReviewers] = useState([]);

    // Modal states
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [uploadName, setUploadName] = useState('');
    const [uploadFile, setUploadFile] = useState(null);
    const [currentUploadItem, setCurrentUploadItem] = useState(null);
    const [showCancelModal, setShowCancelModal] = useState(false);
    const [cancelReason, setCancelReason] = useState('');
    const [currentCancelItem, setCurrentCancelItem] = useState(null);
    const [showCancelCrfModal, setShowCancelCrfModal] = useState(false);
    const [currentCancelCrfItem, setCurrentCancelCrfItem] = useState(null);
    const [showRevisionModal, setShowRevisionModal] = useState(false);
    const [revisionReason, setRevisionReason] = useState('');
    const [revisionRemark, setRevisionRemark] = useState('');
    const [revisionAttachment, setRevisionAttachment] = useState(null);
    const [showAllotModal, setShowAllotModal] = useState(false);
    const [selectedPerson, setSelectedPerson] = useState('');
    const [showApproveModal, setShowApproveModal] = useState(false);
    const [approveReason, setApproveReason] = useState('');
    const [showReviewModal, setShowReviewModal] = useState(false);
    const [reviewReason, setReviewReason] = useState('');
    const [showEditCalibPointModal, setShowEditCalibPointModal] = useState(false);
    const [currentEditCalibPointItem, setCurrentEditCalibPointItem] = useState(null);

    // Fetch calibration data
    const fetchCalibrationData = async () => {
        if (!inwardId || !caliblocation || !calibacc) return;

        setLoading(true);
        try {
            const response = await axios.get(
                `/calibrationprocess/get-performcalibration-list?caliblocation=${encodeURIComponent(caliblocation)}&calibacc=${encodeURIComponent(calibacc)}&inward_id=${inwardId}`
            );

            if (response.data && response.data.instruments) {
                setCalibrationData(response.data.instruments);
            } else {
                console.warn("No instruments found in response");
                setCalibrationData([]);
            }
        } catch (err) {
            console.error("Error fetching calibration list:", err);
            toast.error("Something went wrong while loading calibration list.");
            setCalibrationData([]);
        } finally {
            setLoading(false);
        }
    };

    // Fetch reviewers for allotment
    const fetchReviewers = async () => {
        if (!inwardId || !caliblocation || !calibacc) return;

        try {
            const response = await axios.get(
                `calibrationprocess/edit-bdPerson?inward_id=${inwardId}&caliblocation=${encodeURIComponent(caliblocation)}&calibacc=${encodeURIComponent(calibacc)}`
            );

            if (response.data && response.data.reviewers) {
                setReviewers(response.data.reviewers);
            }
        } catch (error) {
            console.error("Error fetching reviewers:", error);
            toast.error("Failed to load reviewers.");
        }
    };

    // Fetch data on component mount
    useEffect(() => {
        fetchCalibrationData();
        fetchReviewers();
    }, [inwardId, caliblocation, calibacc]);

    // Sort function
    const handleSort = (key) => {
        let direction = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    // Filter and sort data
    const filteredData = calibrationData
        .filter(item =>
            Object.values(item).some(value =>
                value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
            )
        )
        .sort((a, b) => {
            if (!sortConfig.key) return 0;

            const aValue = a[sortConfig.key]?.toString().toLowerCase() || '';
            const bValue = b[sortConfig.key]?.toString().toLowerCase() || '';

            if (aValue < bValue) {
                return sortConfig.direction === 'asc' ? -1 : 1;
            }
            if (aValue > bValue) {
                return sortConfig.direction === 'asc' ? 1 : -1;
            }
            return 0;
        });

    // Pagination calculations
    const totalPages = Math.ceil(filteredData.length / pageSize);
    const startIndex = (currentPage - 1) * pageSize;
    const displayedData = filteredData.slice(startIndex, startIndex + pageSize);

    // Handle page size change
    const handlePageSizeChange = (e) => {
        const newPageSize = Number(e.target.value);
        setPageSize(newPageSize);
        setCurrentPage(1);
    };

    // Handle page change
    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    // Sort icon component
    const SortIcon = ({ column }) => {
        if (sortConfig.key !== column) {
            return (
                <div className="inline-flex flex-col ml-2">
                    <svg className="w-3 h-3 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M5 8l5-5 5 5H5z" />
                    </svg>
                    <svg className="w-3 h-3 text-gray-500 -mt-1" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M15 12l-5 5-5-5h10z" />
                    </svg>
                </div>
            );
        }

        if (sortConfig.direction === 'asc') {
            return (
                <svg className="w-4 h-4 inline ml-2 text-gray-700" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M5 8l5-5 5 5H5z" />
                </svg>
            );
        }

        return (
            <svg className="w-4 h-4 inline ml-2 text-gray-700" fill="currentColor" viewBox="0 0 20 20">
                <path d="M15 12l-5 5-5-5h10z" />
            </svg>
        );
    };

    // Update selectAll state when filtered data changes
    useEffect(() => {
        if (filteredData.length > 0) {
            const allSelected = filteredData.every(item => selectedItems.includes(item.id));
            setSelectAll(allSelected);
        } else {
            setSelectAll(false);
        }
    }, [selectedItems, filteredData]);

    // Reset to first page when search changes
    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm]);

    // Handle action navigation
    const handleAction = (action, item) => {
        const baseUrl = `/dashboards/calibration-process/inward-entry-lab`;
        const params = `?caliblocation=${caliblocation}&calibacc=${calibacc}`;

        switch (action) {
            case 'matrix':
                navigate(`${baseUrl}/matrix/${inwardId}/${item.id}${params}`);
                break;
            case 'uploadDocument':
                setCurrentUploadItem(item);
                setShowUploadModal(true);
                break;
            case 'viewDocuments':
                navigate(`${baseUrl}/view-documents/${inwardId}/${item.id}${params}`);
                break;
            case 'addCrf':
                navigate(`${baseUrl}/add-crf/${inwardId}/${item.id}${params}`);
                break;
            case 'cloneItem':
                navigate(`${baseUrl}/clone-item/${inwardId}/${item.id}${params}`);
                break;
            case 'editInstrumentDetail':
                navigate(`${baseUrl}/edit-instrumental-crf/${inwardId}/${item.id}${params}`);
                break;
            case 'cancelCrf':
                setCurrentCancelCrfItem(item);
                setShowCancelCrfModal(true);
                break;
            case 'requestCancelLRN':
                setCurrentCancelItem(item);
                setShowCancelModal(true);
                break;
            case 'requestRevision':
                setShowRevisionModal(true);
                break;
            case 'editDetailsForRevision':
                navigate(`${baseUrl}/edit-details-revision/${inwardId}/${item.id}${params}`);
                break;
            case 'calibrateStep1':
                navigate(`${baseUrl}/calibrate-step1/${inwardId}/${item.id}${params}`);
                break;
            case 'backToStep1':
                navigate(`${baseUrl}/calibrate-step1/${inwardId}/${item.id}${params}`);
                break;
            case 'calibrateStep2':
                navigate(`${baseUrl}/calibrate-step2/${inwardId}/${item.id}${params}`);
                break;
            case 'changeMaster':
                navigate(`${baseUrl}/change-master/${inwardId}/${item.id}${params}`);
                break;
            case 'calibrateStep3':
                navigate(`${baseUrl}/calibrate-step3/${inwardId}/${item.id}${params}`);
                break;
            case 'editInstrumentDetail2':
                navigate(`${baseUrl}/edit-instrument-detail-2/${inwardId}/${item.id}${params}`);
                break;
            case 'editCalibPoint':
                setCurrentEditCalibPointItem(item);
                setShowEditCalibPointModal(true);
                break;
            case 'viewRawdata':
                navigate(`${baseUrl}/view-rawdata/${inwardId}/${item.id}${params}`);
                break;
            case 'viewTraceability':
                navigate(`${baseUrl}/view-traceability/${item.id}${params}`);
                break;
            case 'viewCertificate':
                navigate(`${baseUrl}/view-certificate/${item.id}${params}`);
                break;
            case 'viewCertificateWithLH':
                navigate(`${baseUrl}/view-certificate-with-lh/${item.id}${params}`);
                break;
            case 'viewCMCCalculation':
                navigate(`${baseUrl}/view-cmc-calculation/${item.id}${params}`);
                break;
            case 'review':
                toast.info("Redirecting to review section...", { duration: 2000 });
                setTimeout(() => {
                    navigate(`${baseUrl}/review/${inwardId}/${item.id}${params}`);
                }, 2000);
                break;
            case 'approve':
                navigate(`${baseUrl}/approve/${inwardId}/${item.id}${params}`);
                break;
            case 'regenerateCache':
                navigate(`${baseUrl}/regenerate-cache/${item.id}${params}`);
                break;
            default:
                console.log('Unknown action:', action);
        }
    };

    const handleBackToList = () => {
  navigate(
    `/dashboards/calibration-process/inward-entry-lab?caliblocation=${caliblocation}&calibacc=${calibacc}`
  );
};

    const handleBulkAction = async (action) => {
        try {
            switch (action) {
                case 'allotPerson':
                    if (selectedItems.length === 0) {
                        toast.error("Please select at least one item");
                        return;
                    }
                    setShowAllotModal(true);
                    break;
                case 'approveSelected':
                    if (selectedItems.length === 0) {
                        toast.error("Please select at least one item");
                        return;
                    }
                    setShowApproveModal(true);
                    break;
                case 'reviewSelected':
                    if (selectedItems.length === 0) {
                        toast.error("Please select at least one item");
                        return;
                    }
                    setShowReviewModal(true);
                    break;
                case 'viewSticker':
                    toast.info('View Sticker functionality - Coming Soon');
                    break;
                case 'viewMultipleDraft':
                    toast.info('View Multiple Draft functionality - Coming Soon');
                    break;
                case 'viewMultipleTraceability':
                    toast.info('View Multiple Traceability functionality - Coming Soon');
                    break;
                case 'viewMultipleApprovedCertificate':
                    toast.info('View Multiple Approved Certificate functionality - Coming Soon');
                    break;
                case 'downloadWithLetterhead':
                    toast.info('Download With Letter head functionality - Coming Soon');
                    break;
                case 'downloadCertificates':
                    toast.info('Download Certificates functionality - Coming Soon');
                    break;
                default:
                    console.log('Unknown bulk action:', action);
            }
        } catch (error) {
            console.error('Bulk action error:', error);
            toast.error(`Failed to perform ${action}`);
        }
    };

    const handleSelectItem = (itemId) => {
        setSelectedItems(prev =>
            prev.includes(itemId)
                ? prev.filter(id => id !== itemId)
                : [...prev, itemId]
        );
    };

    const handleSelectAll = () => {
        if (selectAll) {
            setSelectedItems([]);
        } else {
            setSelectedItems(filteredData.map(item => item.id));
        }
        setSelectAll(!selectAll);
    };

    // Handle file upload
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        setUploadFile(file);
    };

    // Handle revision attachment upload
    const handleRevisionAttachmentChange = (e) => {
        const file = e.target.files[0];
        setRevisionAttachment(file);
    };

    // Handle upload form submission
    const handleUploadSubmit = async () => {
        if (!uploadName.trim()) {
            toast.error("Please enter a name for the document.");
            return;
        }

        if (!uploadFile) {
            toast.error("Please select a file to upload.");
            return;
        }

        try {
            const formData = new FormData();
            formData.append('name', uploadName);
            formData.append('document', uploadFile);
            formData.append('itemId', currentUploadItem.id);
            formData.append('inwardId', inwardId);

            // API call to upload document
            const response = await axios.post('/calibration/upload-document', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            if (response.data.success) {
                toast.success("Document uploaded successfully!");
                // Refresh data
                fetchCalibrationData();
            } else {
                toast.error("Failed to upload document.");
            }

            // Reset form and close modal
            setUploadName('');
            setUploadFile(null);
            setShowUploadModal(false);
            setCurrentUploadItem(null);

        } catch (error) {
            console.error('Upload error:', error);
            toast.error("Failed to upload document.");
        }
    };

    // Handle Cancel LRN submission
    const handleCancelLRNSubmit = async () => {
        if (!cancelReason.trim()) {
            toast.error("Please enter a reason for cancellation.");
            return;
        }

        try {
            // API call to cancel LRN
            const response = await axios.post('/calibration/cancel-lrn', {
                itemId: currentCancelItem.id,
                inwardId: inwardId,
                reason: cancelReason
            });

            if (response.data.success) {
                toast.success("LRN cancelled successfully!");
                // Refresh data
                fetchCalibrationData();
            } else {
                toast.error("Failed to cancel LRN.");
            }

            // Reset form and close modal
            setCancelReason('');
            setShowCancelModal(false);
            setCurrentCancelItem(null);

        } catch (error) {
            console.error('Cancel LRN error:', error);
            toast.error("Failed to cancel LRN.");
        }
    };

    // Handle Cancel CRF confirmation
const handleCancelCrfConfirm = async () => {
    try {
        // API call
        const response = await axios.get(
            `/calibrationprocess/cancel-crf?inward_id=${inwardId}&inst_id=${currentCancelCrfItem.id}`
        );

        if (response.data.status === "true") {
            toast.success(response.data.message || "CRF cancelled successfully!");
            // Refresh data
            fetchCalibrationData();
        } else {
            toast.error("Failed to cancel CRF.");
        }
    } catch (error) {
        console.error("Cancel CRF error:", error);
        toast.error("Failed to cancel CRF.");
    } finally {
        setShowCancelCrfModal(false);
        setCurrentCancelCrfItem(null);
    }
};



    // Handle Request Revision submission
    const handleRevisionSubmit = async () => {
        if (!revisionReason.trim()) {
            toast.error("Please enter a reason for revision.");
            return;
        }

        try {
            const formData = new FormData();
            formData.append('reason', revisionReason);
            formData.append('remark', revisionRemark);
            if (revisionAttachment) {
                formData.append('attachment', revisionAttachment);
            }
            formData.append('inwardId', inwardId);

            // API call to request revision
            const response = await axios.post('/calibration/request-revision', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            if (response.data.success) {
                toast.success("Revision requested successfully!");
                // Refresh data
                fetchCalibrationData();
            } else {
                toast.error("Failed to request revision.");
            }

            // Reset form and close modal
            setRevisionReason('');
            setRevisionRemark('');
            setRevisionAttachment(null);
            setShowRevisionModal(false);

        } catch (error) {
            console.error('Request revision error:', error);
            toast.error("Failed to request revision.");
        }
    };

    // Handle Allot Person submission
const handleAllotPersonSubmit = async () => {
  if (!selectedPerson) {
    toast.error("Please select a person.");
    return;
  }
  if (selectedItems.length === 0) {
    toast.error("Please select at least one item to allot.");
    return;
  }

  try {
    const payload = {
      inwardid: parseInt(inwardId), 
      allotedto: parseInt(selectedPerson), 
      ids: selectedItems, 
    };

    console.log("Submitting payload:", payload);

    const response = await axios.post("/calibrationprocess/allot-item-to-person", payload);

    if (response.data) {
      toast.success("Person allotted successfully!");
      setSelectedPerson("");
      setSelectedItems([]); // Clear selected items
      setShowAllotModal(false);
      fetchCalibrationData(); // Refresh data to reflect changes
    }
  } catch (error) {
    console.error("Allot person error:", error);
    toast.error(error.response?.data?.message || "Failed to allot person.");
  }
};



    // Handle Approve Selected submission
    const handleApproveSubmit = async () => {
        if (!approveReason.trim()) {
            toast.error("Please enter a reason for approve/reject.");
            return;
        }

        try {
            // API call to approve items
            const response = await axios.post('/calibration/approve-items', {
                inwardId: inwardId,
                itemIds: selectedItems,
                reason: approveReason
            });

            if (response.data.success) {
                toast.success("Items approved successfully!");
                // Refresh data
                fetchCalibrationData();
            } else {
                toast.error("Failed to approve items.");
            }

            setApproveReason('');
            setShowApproveModal(false);
        } catch (error) {
            console.error('Approve error:', error);
            toast.error("Failed to approve items.");
        }
    };

    // Handle Review Selected submission
    const handleReviewSubmit = async () => {
        if (!reviewReason.trim()) {
            toast.error("Please enter a reason for review.");
            return;
        }

        try {
            // API call to review items
            const response = await axios.post('/calibration/review-items', {
                inwardId: inwardId,
                itemIds: selectedItems,
                reason: reviewReason
            });

            if (response.data.success) {
                toast.success("Items reviewed successfully!");
                // Refresh data
                fetchCalibrationData();
            } else {
                toast.error("Failed to review items.");
            }

            setReviewReason('');
            setShowReviewModal(false);
        } catch (error) {
            console.error('Review error:', error);
            toast.error("Failed to review items.");
        }
    };

    // Close modal functions
    const handleCloseUploadModal = () => {
        setShowUploadModal(false);
        setUploadName('');
        setUploadFile(null);
        setCurrentUploadItem(null);
    };

    const handleCloseCancelModal = () => {
        setShowCancelModal(false);
        setCancelReason('');
        setCurrentCancelItem(null);
    };

    const handleCloseCancelCrfModal = () => {
        setShowCancelCrfModal(false);
        setCurrentCancelCrfItem(null);
    };

    const handleCloseRevisionModal = () => {
        setShowRevisionModal(false);
        setRevisionReason('');
        setRevisionRemark('');
        setRevisionAttachment(null);
    };

    const handleCloseAllotModal = () => {
        setShowAllotModal(false);
        setSelectedPerson('');
    };

    const handleCloseApproveModal = () => {
        setShowApproveModal(false);
        setApproveReason('');
    };

    const handleCloseReviewModal = () => {
        setShowReviewModal(false);
        setReviewReason('');
    };

    // Handle Edit Calib Point confirmation
    const handleEditCalibPointConfirm = () => {
        const baseUrl = `/dashboards/calibration-process/inward-entry-lab`;
        const params = `?caliblocation=${caliblocation}&calibacc=${calibacc}`;

        // Navigate to edit calib point page
        navigate(`${baseUrl}/edit-calib-point/${inwardId}/${currentEditCalibPointItem.id}${params}`);

        // Close the modal
        setShowEditCalibPointModal(false);
        setCurrentEditCalibPointItem(null);
    };

    // Handle Edit Calib Point modal close
    const handleCloseEditCalibPointModal = () => {
        setShowEditCalibPointModal(false);
        setCurrentEditCalibPointItem(null);
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                        <div className="flex h-[60vh] items-center justify-center text-gray-600">
                            <svg className="animate-spin h-6 w-6 mr-2 text-blue-600" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 000 8v4a8 8 0 01-8-8z"></path>
                            </svg>
                            Loading Perform Calibration data...
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-white">
                {/* Header */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
                    <div className="flex items-center justify-between p-4 border-b border-gray-200">
                        <h1 className="text-xl font-semibold text-gray-800">Perform Calibration</h1>
                        <Button
                            onClick={handleBackToList}
                            className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                        >
                            ← Back to Inward Entry List
                        </Button>
                    </div>
                </div>

                {/* Main Content */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                    {/* Controls */}
                    <div className="p-4 border-b border-gray-200">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-600">Search:</span>
                                <input
                                    type="text"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="border border-gray-300 rounded px-3 py-1 text-sm w-48 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="Search ID, Customer..."
                                />
                            </div>
                        </div>
                    </div>

                    {/* Table */}
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm border-collapse min-w-[1200px]">
                            <thead>
                                <tr className="bg-gray-200">
                                    <th className="text-center p-3 font-semibold text-gray-700 border border-gray-300 w-16">
                                        <div className="flex flex-col items-center gap-1">
                                            S NO
                                            <input
                                                type="checkbox"
                                                checked={selectAll}
                                                onChange={handleSelectAll}
                                                className="rounded focus:ring-blue-500 mt-1"
                                            />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 min-w-[160px] cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('refNo')}
                                    >
                                        <div className="flex items-center justify-center">
                                            <span>Ref No</span>
                                            <SortIcon column="refNo" />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 min-w-[120px] cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('name')}
                                    >
                                        <div className="flex items-center justify-center">
                                            <span>Name</span>
                                            <SortIcon column="name" />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 min-w-[120px] cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('typeOfInstrument')}
                                    >
                                        <div className="flex flex-col items-center gap-1">
                                            <span>Type of</span>
                                            <span>Instrument</span>
                                            <SortIcon column="typeOfInstrument" />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 w-20 cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('idNo')}
                                    >
                                        <div className="flex items-center justify-center">
                                            <span>Id no</span>
                                            <SortIcon column="idNo" />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 w-20 cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('serialNo')}
                                    >
                                        <div className="flex items-center justify-center">
                                            <span>Serial no</span>
                                            <SortIcon column="serialNo" />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 min-w-[120px] cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('calibrationMethod')}
                                    >
                                        <div className="flex flex-col items-center gap-1">
                                            <span>Calibration</span>
                                            <span>Method</span>
                                            <SortIcon column="calibrationMethod" />
                                        </div>
                                    </th>
                                    <th
                                        className="text-center p-3 font-semibold text-gray-700 border border-gray-300 min-w-[100px] cursor-pointer hover:bg-gray-100"
                                        onClick={() => handleSort('allotedTo')}
                                    >
                                        <div className="flex items-center justify-center">
                                            <span>Alloted to</span>
                                            <SortIcon column="allotedTo" />
                                        </div>
                                    </th>
                                    <th className="text-center p-3 font-semibold text-gray-700 border border-gray-300 w-20">
                                        <span>Matrix</span>
                                    </th>
                                    <th className="text-center p-3 font-semibold text-gray-700 border border-gray-300 min-w-[80px]">
                                        <span>Perform</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                {displayedData.length > 0 ? (
                                    displayedData.map((item, index) => (
                                        <tr key={item.id} className="border-b border-gray-200 hover:bg-gray-50">
                                            <td className="p-3 text-center border border-gray-200">
                                                <div className="flex flex-col items-center gap-2">
                                                    <span className="font-medium">{startIndex + index + 1}</span>
                                                    <input
                                                        type="checkbox"
                                                        checked={selectedItems.includes(item.id)}
                                                        onChange={() => handleSelectItem(item.id)}
                                                        className="rounded focus:ring-blue-500"
                                                    />
                                                </div>
                                            </td>
                                            <td className="p-3 border border-gray-200">
                                                <div className="text-xs whitespace-pre-line leading-relaxed">
                                                    {item.bookingrefno && (
                                                        <>
                                                            <strong>BRN:</strong> {item.bookingrefno}
                                                            {item.rev > 0 && `/R${item.rev}`}
                                                            <br />
                                                        </>
                                                    )}
                                                    {item.lrn && (
                                                        <>
                                                            <strong>LRN:</strong> {item.lrn}
                                                            <br />
                                                        </>
                                                    )}
                                                    {item.ulrno && (
                                                        <>
                                                            <strong>ULR NO.:</strong> {item.ulrno}
                                                        </>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="p-3 border border-gray-200">
                                                <span className="font-medium">{item.name}</span>
                                            </td>
                                            <td className="p-3 border border-gray-200">
                                                {item.type_of_instrument || item.name}
                                            </td>
                                            <td className="p-3 text-center border border-gray-200">
                                                <span className="font-medium">{item.idno}</span>
                                            </td>
                                            <td className="p-3 text-center border border-gray-200">
                                                <span className="font-medium">{item.serialno}</span>
                                            </td>
                                            <td className="p-3 border border-gray-200">
                                                <span className="font-medium">{item.sop}</span>
                                            </td>
                                            <td className="p-3 border border-gray-200">
                                                {item.allotedto}
                                            </td>
                                            <td className="p-3 text-center border border-gray-200">
                                                <Button
                                                    onClick={() => handleAction('matrix', item)}
                                                    className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-3 py-1 rounded text-xs font-medium transition-colors"
                                                >
                                                    Matrix
                                                </Button>
                                            </td>
                                            <td className="p-3 text-center border border-gray-200">
                                                <PerformActions
                                                    item={item}
                                                    onAction={handleAction}
                                                />
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="10" className="p-4 text-center text-gray-500">
                                            No calibration instruments found
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination Section */}
                    <div className="p-4 border-t border-gray-200">
                        <div className="flex flex-col justify-between space-y-4 sm:flex-row sm:items-center sm:space-y-0">
                            {/* Show entries section */}
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                                <span>Show</span>
                                <Select
                                    data={[10, 20, 30, 40, 50, 100]}
                                    value={pageSize}
                                    onChange={handlePageSizeChange}
                                    classNames={{
                                        root: "w-fit",
                                        select: "h-7 rounded-full py-1 text-xs border border-gray-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
                                    }}
                                />
                                <span>entries</span>
                                {selectedItems.length > 0 && (
                                    <span className="ml-4 text-blue-600 font-medium">
                                        ({selectedItems.length} selected)
                                    </span>
                                )}
                            </div>

                            {/* Pagination component */}
                            <div>
                                <Pagination
                                    total={totalPages}
                                    value={currentPage}
                                    onChange={handlePageChange}
                                    siblings={2}
                                    boundaries={1}
                                >
                                    <PaginationPrevious />
                                    <PaginationItems />
                                    <PaginationNext />
                                </Pagination>
                            </div>

                            {/* Entries info */}
                            <div className="truncate text-sm text-gray-600">
                                {filteredData.length > 0 ? (
                                    `${startIndex + 1} - ${Math.min(startIndex + pageSize, filteredData.length)} of ${filteredData.length} entries`
                                ) : (
                                    "0 entries"
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="p-4 border-t border-gray-200 bg-gray-50">
                        <div className="flex flex-wrap gap-2">
                            <Button
                                onClick={() => handleBulkAction('allotPerson')}
                                className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                Allot Person
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('approveSelected')}
                                className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                Approve Selected
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('reviewSelected')}
                                className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                Review Selected
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('viewSticker')}
                                className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                View Sticker
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('viewMultipleDraft')}
                                className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                View Multiple Draft
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('viewMultipleTraceability')}
                                className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                View Multiple Traceability
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('viewMultipleApprovedCertificate')}
                                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                View Multiple Approved Certificate
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('downloadWithLetterhead')}
                                className="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                Download With Letter head
                            </Button>
                            <Button
                                onClick={() => handleBulkAction('downloadCertificates')}
                                className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                            >
                                Download Certificates
                            </Button>
                        </div>
                    </div>
                </div>

                {/* All modals remain the same as in your original code */}
                {/* Upload Document Modal */}
                {showUploadModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-auto border border-gray-200 mb-30">
                            {/* Modal Header */}
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Upload Calibration Document</h2>
                                <button
                                    onClick={handleCloseUploadModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            {/* Modal Body */}
                            <div className="p-6">
                                {/* Name Field */}
                                <div className="mb-4">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Name
                                    </label>
                                    <input
                                        type="text"
                                        value={uploadName}
                                        onChange={(e) => setUploadName(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                                        placeholder="Enter document name"
                                    />
                                </div>

                                {/* Upload Document Field */}
                                <div className="mb-6">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Upload Document
                                    </label>
                                    <div className="relative">
                                        <input
                                            type="file"
                                            onChange={handleFileChange}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 file:mr-4 file:py-1 file:px-4 file:rounded file:border-0 file:text-sm file:font-medium file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200 text-sm"
                                            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                                        />
                                    </div>
                                    {uploadFile && (
                                        <p className="mt-2 text-sm text-gray-600">
                                            Selected: {uploadFile.name}
                                        </p>
                                    )}
                                </div>

                                {/* Add Image Button */}
                                <div className="mb-6">
                                    <Button
                                        onClick={() => document.querySelector('input[type="file"]').click()}
                                        className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                    >
                                        Add Image
                                    </Button>
                                </div>
                            </div>

                            {/* Modal Footer */}
                            <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseUploadModal}
                                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Close
                                </Button>
                                <Button
                                    onClick={handleUploadSubmit}
                                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Save
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Cancel LRN Modal */}
                {showCancelModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-auto border border-gray-200 mb-30">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Cancel LRN</h2>
                                <button
                                    onClick={handleCloseCancelModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <div className="mb-4">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Reason For Cancellation
                                    </label>
                                    <textarea
                                        value={cancelReason}
                                        onChange={(e) => setCancelReason(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none"
                                        placeholder="Reason For Accept / Reject"
                                        rows={4}
                                    />
                                    <p className="text-red-500 text-xs mt-1">This field is required *</p>
                                </div>
                            </div>

                            <div className="flex justify-end gap-2 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseCancelModal}
                                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Close
                                </Button>
                                <Button
                                    onClick={handleCancelLRNSubmit}
                                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Review
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Cancel CRF Modal */}
                {showCancelCrfModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-auto border border-gray-200 mb-30">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Cancel CRF</h2>
                                <button
                                    onClick={handleCloseCancelCrfModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <p className="text-sm font-medium text-gray-700 mb-4">
                                    Are you sure you want to delete?
                                </p>
                            </div>

                            <div className="flex justify-end gap-2 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={() => handleCancelCrfConfirm()}
                                    className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Yes
                                </Button>
                                <Button
                                    onClick={handleCloseCancelCrfModal}
                                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    No
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Request Revision Modal */}
                {showRevisionModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-auto border border-gray-200 mb-30">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Request Revision</h2>
                                <button
                                    onClick={handleCloseRevisionModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <div className="mb-4">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Reason For Revision
                                    </label>
                                    <textarea
                                        value={revisionReason}
                                        onChange={(e) => setRevisionReason(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none"
                                        placeholder="Reason For Accept / Reject"
                                        rows={3}
                                    />
                                    <p className="text-red-500 text-xs mt-1">This field is required *</p>
                                </div>

                                <div className="mb-4">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Remark
                                    </label>
                                    <textarea
                                        value={revisionRemark}
                                        onChange={(e) => setRevisionRemark(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none"
                                        placeholder="Enter remarks"
                                        rows={2}
                                    />
                                </div>

                                <div className="mb-4">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Attachment
                                    </label>
                                    <div className="flex items-center">
                                        <input
                                            type="file"
                                            onChange={handleRevisionAttachmentChange}
                                            className="hidden"
                                            id="revision-attachment"
                                        />
                                        <label
                                            htmlFor="revision-attachment"
                                            className="px-4 py-2 bg-gray-100 border border-gray-300 rounded text-sm cursor-pointer hover:bg-gray-200 transition-colors"
                                        >
                                            Choose File
                                        </label>
                                        <span className="ml-2 text-sm text-gray-500 truncate">
                                            {revisionAttachment ? revisionAttachment.name : "No file chosen"}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="flex justify-end gap-2 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseRevisionModal}
                                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Close
                                </Button>
                                <Button
                                    onClick={handleRevisionSubmit}
                                    className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Save changes
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Allot Items to Person Modal */}
                {showAllotModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-auto border border-gray-200 mb-30 ">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Allot Items to Person</h2>
                                <button
                                    onClick={handleCloseAllotModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <div className="mb-6">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Select person
                                    </label>
                                    <select
                                        value={selectedPerson}
                                        onChange={(e) => setSelectedPerson(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                                    >
                                        <option value="">Select</option>
                                        {reviewers.map((person) => (
                                            <option key={person.id} value={person.id}>
                                                {`${person.firstname} ${person.middlename || ''} ${person.lastname}`}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseAllotModal}
                                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Close
                                </Button>
                                <Button
                                    onClick={handleAllotPersonSubmit}
                                    className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Save changes
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Approve Calibration Certificate Modal */}
                {showApproveModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-auto border border-gray-200 mb-30">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Approve Calibration Certificate</h2>
                                <button
                                    onClick={handleCloseApproveModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <div className="mb-6">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Reason For Action
                                    </label>
                                    <textarea
                                        value={approveReason}
                                        onChange={(e) => setApproveReason(e.target.value)}
                                        className="w-full px-3 py-2 bg-yellow-100 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                                        placeholder="Reason For Accept / Reject"
                                        rows={4}
                                    />
                                    <p className="text-red-500 text-xs mt-1">This field is required *</p>
                                </div>
                            </div>

                            <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseApproveModal}
                                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Reject
                                </Button>
                                <Button
                                    onClick={handleApproveSubmit}
                                    className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Approve
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Review Calibration Certificate Modal */}
                {showReviewModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-auto border border-gray-200 mb-30">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Review Calibration Certificate</h2>
                                <button
                                    onClick={handleCloseReviewModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <div className="mb-6">
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Reason For Action
                                    </label>
                                    <textarea
                                        value={reviewReason}
                                        onChange={(e) => setReviewReason(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                                        placeholder="Reason For Accept / Reject"
                                        rows={4}
                                    />
                                </div>
                            </div>

                            <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseReviewModal}
                                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Reject
                                </Button>
                                <Button
                                    onClick={handleReviewSubmit}
                                    className="bg-indigo-500 hover:bg-fuchsia-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    Review
                                </Button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Edit Calib Point Confirmation Modal */}
                {showEditCalibPointModal && (
                    <div className="fixed inset-0 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-auto border border-gray-200 mb-30">
                            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
                                <h2 className="text-lg font-semibold text-gray-800">Validate</h2>
                                <button
                                    onClick={handleCloseEditCalibPointModal}
                                    className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded hover:bg-gray-100"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            <div className="p-6">
                                <p className="text-gray-700 text-sm mb-6">
                                    Are you sure you want to Process?
                                </p>
                            </div>

                            <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-200 bg-gray-50">
                                <Button
                                    onClick={handleCloseEditCalibPointModal}
                                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    CANCEL
                                </Button>
                                <Button
                                    onClick={handleEditCalibPointConfirm}
                                    className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium transition-colors"
                                >
                                    OK
                                </Button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PerformCalibration;