import  { useState } from 'react';




const InstrumentEntryForm = () => {
  const [formData, setFormData] = useState({
    category: '',
    productType: '',
    vertical: '',
    instrumentLocation: '',
    instrumentName: '',
    description: '',
    nickName: '',
    idNo: '',
    serialNo: '',
    make: '',
    model: '',
    purchaseDate: '',
    manufacturerDetails: '',
    batchNo: '',
    mfdDate: '',
    expiryDate: '',
    qty: '',
    instrumentRange: '',
    leastCount: '',
    calibrationFrequency: '',
    instrumentAllowedFor: '',
    calibrationRequired: '',
    wiReference: '',
    softwareFirmwareDetails: '',
    acceptanceCriteria: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };


  const handleSubmit = () => {
    console.log('Form Data:', formData);
    alert('Instrument added successfully!');
  };

  const handleBackToList = () => {
    console.log('Navigate back to instrument list');
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h1 className="text-xl font-semibold text-gray-800">Instrument Entry Form</h1>
          <button 
            onClick={handleBackToList}
            className="px-4 py-2 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors"
          >
            Go Back to MM Instrument
          </button>
        </div>

        {/* Form Content */}
        <div className="p-6">
          <div className="grid grid-cols-12 gap-4">
            
            {/* Category */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Category</label>
              <div className="col-span-9">
                <select 
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Category</option>
                  <option value="test">Test</option>
                  <option value="camera & camera accessories">Camera & Camera Accessories</option>
                  <option value="staff uniform">Staff Uniform</option>
                  <option value="printing">Printing</option>
                  <option value="non standard solutions">Non Standard Solutions</option>
                  <option value="freight/any other charge">Freight/Any Other Charge</option>
                  <option value="containers">Containers</option>
                  <option value="jigs & fixtures">Jigs & Fixtures</option>
                  <option value="vehicle">Vehicle</option>
                  <option value="equipments">Equipments</option>
                  <option value="computer & accessories">Computer & Accessories</option>
                  <option value="srm">SRm</option>
                  <option value="glassware">Glassware</option>
                  <option value="crm">CRM</option>
                  <option value="stationary">Stationary</option>
                  <option value="furniture & fixtures">Furniture & Fixtures</option>
                  <option value="tools">Tools</option>
                  <option value="masters">Masters</option>
                 


                </select>
              </div>
            </div>

            {/* Product Type / Subcategory */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Product Type / Subcategory</label>
              <div className="col-span-9">
                <select 
                  name="productType"
                  value={formData.productType}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Product Type</option>
                  <option value="digital">Digital</option>
                  <option value="analog">Analog</option>
                  <option value="mechanical">Mechanical</option>
                </select>
              </div>
            </div>

            {/* Vertical */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Vertical</label>
              <div className="col-span-9">
                <select 
                  name="vertical"
                  value={formData.vertical}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Vertical</option>
                  <option value="automotive">Automotive</option>
                  <option value="electronics">Electronics</option>
                  <option value="pharmaceutical">Pharmaceutical</option>
                </select>
              </div>
            </div>

            {/* Instrument Location */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Instrument Location</label>
              <div className="col-span-9">
                <select 
                  name="instrumentLocation"
                  value={formData.instrumentLocation}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Location</option>
                  <option value="lab1">Laboratory 1</option>
                  <option value="lab2">Laboratory 2</option>
                  <option value="production">Production Floor</option>
                </select>
              </div>
            </div>

            {/* Instrument Name */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Instrument Name</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="instrumentName"
                  value={formData.instrumentName}
                  onChange={handleInputChange}
                  placeholder="Instrument Name"
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Description */}
            <div className="col-span-12 grid grid-cols-12 gap-4">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700 pt-2">Description</label>
              <div className="col-span-9">
                <textarea 
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Description"
                  rows="3"
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
                />
              </div>
            </div>

            {/* Nick Name */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Nick Name</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="nickName"
                  value={formData.nickName}
                  onChange={handleInputChange}
                  placeholder="Nick Name"
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* ID No */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">ID No</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="idNo"
                  value={formData.idNo}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Serial No */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Serial No</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="serialNo"
                  value={formData.serialNo}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Make */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Make</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="make"
                  value={formData.make}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Model */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Model</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="model"
                  value={formData.model}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Purchase Date */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Purchase Date</label>
              <div className="col-span-9">
                <input 
                  type="date"
                  name="purchaseDate"
                  value={formData.purchaseDate}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Name and Address of manufacturer */}
            <div className="col-span-12 grid grid-cols-12 gap-4">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700 pt-2">Name and Address of manufacturer</label>
              <div className="col-span-9">
                <textarea 
                  name="manufacturerDetails"
                  value={formData.manufacturerDetails}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
                />
              </div>
            </div>

            {/* Batch no */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Batch no</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="batchNo"
                  value={formData.batchNo}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* MFD Date */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">MFD Date</label>
              <div className="col-span-9">
                <input 
                  type="date"
                  name="mfdDate"
                  value={formData.mfdDate}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Expiry Date */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Expiry Date</label>
              <div className="col-span-9">
                <input 
                  type="date"
                  name="expiryDate"
                  value={formData.expiryDate}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Qty */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Qty</label>
              <div className="col-span-9">
                <input 
                  type="number"
                  name="qty"
                  value={formData.qty}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Instrument Range */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Instrument Range</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="instrumentRange"
                  value={formData.instrumentRange}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Leastcount */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Leastcount</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="leastCount"
                  value={formData.leastCount}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Frequency of calibration if required */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Frequency of calibration if required</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="calibrationFrequency"
                  value={formData.calibrationFrequency}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Instrument allowed for */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Instrument allowed for</label>
              <div className="col-span-9">
                <select 
                  name="instrumentAllowedFor"
                  value={formData.instrumentAllowedFor}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Option</option>
                  <option value="internal">Internal Use</option>
                  <option value="external">External Use</option>
                  <option value="both">Both</option>
                </select>
              </div>
            </div>

            {/* Calibration Required */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Calibration Required</label>
              <div className="col-span-9">
                <select 
                  name="calibrationRequired"
                  value={formData.calibrationRequired}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>

            {/* WI Reference */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">WI Reference</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="wiReference"
                  value={formData.wiReference}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Software / Firmware details */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Software / Firmware details</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="softwareFirmwareDetails"
                  value={formData.softwareFirmwareDetails}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Acceptance Criteria (% DROP/DRIFT/PASS) */}
            <div className="col-span-12 grid grid-cols-12 gap-4 items-center">
              <label className="col-span-3 text-right text-sm font-medium text-gray-700">Acceptance Criteria (% DROP/DRIFT/PASS)</label>
              <div className="col-span-9">
                <input 
                  type="text"
                  name="acceptanceCriteria"
                  value={formData.acceptanceCriteria}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

          </div>

          {/* Submit Button */}
          <div className="flex justify-end mt-8">
            <button 
              onClick={handleSubmit}
              className="px-6 py-2 bg-green-500 text-white font-medium rounded hover:bg-green-600 transition-colors"
            >
              Add Instrument
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstrumentEntryForm;