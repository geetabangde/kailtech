// import {
//   Menu,
//   MenuButton,
//   MenuItem,
//   MenuItems,
//   Transition,
// } from "@headlessui/react";
// import {
//   EllipsisHorizontalIcon,
//   PencilIcon,
//   EyeIcon,
//   // WrenchScrewdriverIcon,
//   // ClipboardDocumentListIcon,
//   // ShieldCheckIcon,
//   // DocumentTextIcon,
//    BookOpenIcon,
//   //CopyIcon,
//   DocumentPlusIcon,
//   ClockIcon,  
//   DocumentIcon,
//   TrashIcon,
// } from "@heroicons/react/24/outline";
// import clsx from "clsx";
// import { Fragment, useCallback, useState } from "react";
// import PropTypes from "prop-types";
// import { ConfirmModal } from "components/shared/ConfirmModal";
// import { Button } from "components/ui";
// //import axios from "axios";
// //import { toast } from "sonner";
// import { useNavigate} from "react-router";

// const confirmMessages = {
//   pending: {
//     description:
//       "Are you sure you want to delete this order? Once deleted, it cannot be restored.",
//   },
//   success: {
//     title: "Order Deleted",
//   },
// };

// export function RowActions({ row, table }) {
//   const navigate = useNavigate();
//   //const location = useLocation();
//   const [deleteModalOpen, setDeleteModalOpen] = useState(false);
//   const [confirmDeleteLoading, setConfirmDeleteLoading] = useState(false);
//   const [deleteSuccess, setDeleteSuccess] = useState(false);
//   const [deleteError] = useState(false);

//   const permissions =
//     localStorage.getItem("userPermissions")?.split(",").map(Number) || [];

//   const closeModal = () => {
//     setDeleteModalOpen(false);
//   };

//   const openModal = () => {
//     setDeleteModalOpen(true);
//     //setDeleteError(false);
//     setDeleteSuccess(false);
//   };

//   const handleDeleteRows = useCallback(() => {
//     setConfirmDeleteLoading(true);
//     setTimeout(() => {
//       table.options.meta?.deleteRow(row);
//       setDeleteSuccess(true);
//       setConfirmDeleteLoading(false);
//     }, 1000);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [row]);

//   const state = deleteError ? "error" : deleteSuccess ? "success" : "pending";

//   const actions = [
    
//       {
//     label: "View ReviewForm",
//     icon: EyeIcon,
//     permission: 401,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/view-review-form`
//       ),
//   },
//     {
//     label: "Change File",
//     icon: DocumentIcon,
//     permission: 402,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/change-file/${row.original.id}`
//       ),
//   },
//   {
//     label: "View Certificate",
//    //icon: CertificateIcon,
//     permission: 403,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/view-certificate/${row.original.id}`
//       ),
//   },
//   {
//     label: "Validity Detail",
//     icon: ClockIcon,
//     permission: 404,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/validity-detail/${row.original.id}`
//       ),
//   },
//   {
//     label: "Edit Validity",
//     icon: PencilIcon,
//     permission: 405,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/edit-validity/${row.original.id}`
//       ),
//   },
//   {
//     label: "Add IMC",
//     icon: DocumentPlusIcon,
//     permission: 406,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/add-imc/${row.original.id}`
//       ),
//   },
//   {
//     label: "Clone Certificate Details",
//     icon: BookOpenIcon,
//     permission: 407,
//     onClick: () =>
//       navigate(
//         `/dashboards/material-list/calibration/maintenance-equipment-history/clone-certificate-details/${row.original.id}`
//       ),
//   },

//     // Delete - This will be at the bottom with different styling
//     {
//       label: "Delete",
//       icon: TrashIcon,
//       permission: 408, // Add appropriate permission number
//       onClick: openModal,
//       isDelete: true, // Special flag for delete styling
//     },
//   ];

//   // Filter actions based on permission (if defined)
//   const filteredActions = actions.filter(
//     (action) =>
//       !action.permission || permissions.includes(action.permission)
//   );

//   return (
//     <>
//       <div className="flex justify-center space-x-1.5">
//         <Menu as="div" className="relative inline-block text-left">
//           <MenuButton as={Button} isIcon className="size-8 rounded-full">
//             <EllipsisHorizontalIcon className="size-4.5" />
//           </MenuButton>

//           <Transition
//             as={Fragment}
//             enter="transition ease-out"
//             enterFrom="opacity-0 translate-y-2"
//             enterTo="opacity-100 translate-y-0"
//             leave="transition ease-in"
//             leaveFrom="opacity-100 translate-y-0"
//             leaveTo="opacity-0 translate-y-2"
//           >
//             <MenuItems
//               anchor={{ to: "bottom end", gap: 12 }}
//               className="absolute z-50 w-56 rounded-lg border border-gray-300 bg-white py-1 shadow-lg shadow-gray-200/50 dark:border-dark-500 dark:bg-dark-750 dark:shadow-none"
//             >
//               {filteredActions.map((action) => (
//                 <MenuItem key={action.label}>
//                   {({ focus }) => {
//                     const IconComponent = action.icon || PencilIcon;
//                     return (
//                       <button
//                         onClick={action.onClick}
//                         className={clsx(
//                           "flex h-9 w-full items-center space-x-3 px-3 tracking-wide outline-none transition-colors",
//                           focus
//                             ? "bg-gray-100 text-gray-800 dark:bg-dark-600 dark:text-dark-100"
//                             : "",
//                           action.isDelete 
//                             ? "text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/20" 
//                             : ""
//                         )}
//                       >
//                         <IconComponent className="size-4.5 stroke-1" />
//                         <span>{action.label}</span>
//                       </button>
//                     );
//                   }}
//                 </MenuItem>
//               ))}
//             </MenuItems>
//           </Transition>
//         </Menu>
//       </div>

//       <ConfirmModal
//         show={deleteModalOpen}
//         onClose={closeModal}
//         messages={confirmMessages}
//         onOk={handleDeleteRows}
//         confirmLoading={confirmDeleteLoading}
//         state={state}
//       />
//     </>
//   );
// }

// RowActions.propTypes = {
//   row: PropTypes.object,
//   table: PropTypes.object,
// };



import {
  Menu,
  MenuButton,
  MenuItem,
  MenuItems,
  Transition,
} from "@headlessui/react";
import {
  EllipsisHorizontalIcon,
  PencilIcon,
  EyeIcon,
  BookOpenIcon,
  DocumentPlusIcon,
  ClockIcon,  
  DocumentIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import clsx from "clsx";
import { Fragment, useCallback, useState } from "react";
import PropTypes from "prop-types";
import { ConfirmModal } from "components/shared/ConfirmModal";
import { Button } from "components/ui";
import { useNavigate} from "react-router";

const confirmMessages = {
  pending: {
    description:
      "Are you sure you want to delete this order? Once deleted, it cannot be restored.",
  },
  success: {
    title: "Order Deleted",
  },
};

// Upload Certificate Scan Component
function UploadCertificateScanModal({ isOpen, onClose }) {
  const handleFileChange = (event) => {
    // File handling logic can be added here when needed
    console.log("File selected:", event.target.files[0]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4 border border-gray-300">
        {/* Header */}
        <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-lg">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">
              Upload Certificate Scan
            </h3>
            <Button  className="h-8 space-x-1.5 rounded-md px-3 text-xs "
          color="primary"
              onClick={onClose}
             
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </Button>
          </div>
        </div>

        {/* File Upload Section */}
        <div className="px-6 py-4">
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-gray-700 w-20">File</span>
              <div className="flex-1">
                <input
                  type="file"
                  onChange={handleFileChange}
                  className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 rounded-b-lg flex justify-end space-x-3">
          <Button  className="h-8 space-x-1.5 rounded-md px-3 text-xs "
          color="primary"
            
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button  className="h-8 space-x-1.5 rounded-md px-3 text-xs "
          color="primary"
          >
            Upload Certificate
          </Button>
        </div>
      </div>
    </div>
  );
}

export function RowActions({ row, table }) {
  const navigate = useNavigate();
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [confirmDeleteLoading, setConfirmDeleteLoading] = useState(false);
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [deleteError] = useState(false);

  const permissions =
    localStorage.getItem("userPermissions")?.split(",").map(Number) || [];

  const closeModal = () => {
    setDeleteModalOpen(false);
  };

  const openModal = () => {
    setDeleteModalOpen(true);
    setDeleteSuccess(false);
  };

  const openUploadModal = () => {
    setUploadModalOpen(true);
  };

  const closeUploadModal = () => {
    setUploadModalOpen(false);
  };

  const handleDeleteRows = useCallback(() => {
    setConfirmDeleteLoading(true);
    setTimeout(() => {
      table.options.meta?.deleteRow(row);
      setDeleteSuccess(true);
      setConfirmDeleteLoading(false);
    }, 1000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [row]);

  const state = deleteError ? "error" : deleteSuccess ? "success" : "pending";

  const actions = [
    {
      label: "View ReviewForm",
      icon: EyeIcon,
      permission: 401,
      onClick: () =>
        navigate(
          `/dashboards/material-list/calibration/maintenance-equipment-history/view-review-form`
        ),
    },
    {
      label: "Change File",
      icon: DocumentIcon,
      permission: 402,
      onClick: openUploadModal,
    },
    {
      label: "View Certificate",
      permission: 403,
      onClick: () =>
        navigate(
          `/dashboards/material-list/calibration/maintenance-equipment-history/view-certificate`
        ),
    },
    {
      label: "Validity Detail",
      icon: ClockIcon,
      permission: 404,
      onClick: () =>
        navigate(
          `/dashboards/material-list/calibration/maintenance-equipment-history/validity-detail`
        ),
    },
    {
      label: "Edit Validity",
      icon: PencilIcon,
      permission: 405,
      onClick: () =>
        navigate(
          `/dashboards/material-list/calibration/maintenance-equipment-history/edit-validity`
        ),
    },
    {
      label: "Add IMC",
      icon: DocumentPlusIcon,
      permission: 406,
      onClick: () =>
        navigate(
          `/dashboards/material-list/calibration/maintenance-equipment-history/add-imc`
        ),
    },
    {
      label: "Clone Certificate Details",
      icon: BookOpenIcon,
      permission: 407,
      onClick: () =>
        navigate(
          `/dashboards/material-list/calibration/maintenance-equipment-history/clone-certificate-details`
        ),
    },
    // Delete - This will be at the bottom with different styling
    {
      label: "Delete",
      icon: TrashIcon,
      permission: 408,
      onClick: openModal,
      isDelete: true,
    },
  ];

  // Filter actions based on permission (if defined)
  const filteredActions = actions.filter(
    (action) =>
      !action.permission || permissions.includes(action.permission)
  );

  return (
    <>
      <div className="flex justify-center space-x-1.5">
        <Menu as="div" className="relative inline-block text-left">
          <MenuButton as={Button} isIcon className="size-8 rounded-full">
            <EllipsisHorizontalIcon className="size-4.5" />
          </MenuButton>

          <Transition
            as={Fragment}
            enter="transition ease-out"
            enterFrom="opacity-0 translate-y-2"
            enterTo="opacity-100 translate-y-0"
            leave="transition ease-in"
            leaveFrom="opacity-100 translate-y-0"
            leaveTo="opacity-0 translate-y-2"
          >
            <MenuItems
              anchor={{ to: "bottom end", gap: 12 }}
              className="absolute z-50 w-56 rounded-lg border border-gray-300 bg-white py-1 shadow-lg shadow-gray-200/50 dark:border-dark-500 dark:bg-dark-750 dark:shadow-none"
            >
              {filteredActions.map((action) => (
                <MenuItem key={action.label}>
                  {({ focus }) => {
                    const IconComponent = action.icon || PencilIcon;
                    return (
                      <button
                        onClick={action.onClick}
                        className={clsx(
                          "flex h-9 w-full items-center space-x-3 px-3 tracking-wide outline-none transition-colors",
                          focus
                            ? "bg-gray-100 text-gray-800 dark:bg-dark-600 dark:text-dark-100"
                            : "",
                          action.isDelete 
                            ? "text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/20" 
                            : ""
                        )}
                      >
                        <IconComponent className="size-4.5 stroke-1" />
                        <span>{action.label}</span>
                      </button>
                    );
                  }}
                </MenuItem>
              ))}
            </MenuItems>
          </Transition>
        </Menu>
      </div>

      {/* Upload Certificate Scan Modal - Without black background */}
      <UploadCertificateScanModal 
        isOpen={uploadModalOpen} 
        onClose={closeUploadModal} 
      />

      <ConfirmModal
        show={deleteModalOpen}
        onClose={closeModal}
        messages={confirmMessages}
        onOk={handleDeleteRows}
        confirmLoading={confirmDeleteLoading}
        state={state}
      />
    </>
  );
}

RowActions.propTypes = {
  row: PropTypes.object,
  table: PropTypes.object,
};