import { ArrowPathIcon, CheckBadgeIcon, ClockIcon, TruckIcon, XCircleIcon } from "@heroicons/react/24/outline";

export const orderStatusOptions = [
    {
        value: 'shipping',
        label: 'Shipping',
        color: 'info',
        icon: TruckIcon
    },
    {
        value: 'pending',
        label: 'Pending',
        color: 'warning',
        icon: ClockIcon
    },
    {
        value: 'completed',
        label: 'Completed',
        color: 'success',
        icon: CheckBadgeIcon
    },
    {
        value: 'processing',
        label: 'Processing',
        color: 'primary',
        icon: ArrowPathIcon
    },
    {
        value: 'cancelled',
        label: 'Cancelled',
        color: 'error',
        icon: XCircleIcon
    }
]

export const ordersList = [
    {
        order_id: "KTRC-BM-EO-007",
        created_at: "1599254400000", // 05/09/2020
        customer: {
            name: "Electrosurgery Analyzer",
        },
        total: 1,
        profit: 0,
        payment_status: "paid",
        order_status: "completed",
        category: "Masters",
        location: "ELECTRO-TECHNICAL",
        make: "Fluke",
        model: "QA-ES MKIII",
        serial_no: "4837012",
        new_id_no: "KTRC-MS-0066",
        shipping_address: { street: "Lab A", line: "Shelf 1" },
        products: [],
        subtotal: 0,
        delivery_fee: 0,
        tax: 0,
        total_amount_due: 0,
    },
    {
        order_id: "KTRC-CAL-EO-001",
        created_at: "1444953600000", // 16/10/2015
        customer: {
            name: "Multi-Product Calibrator",
        },
        total: 1,
        profit: 0,
        payment_status: "paid",
        order_status: "completed",
        category: "Masters",
        location: "ELECTRO-TECHNICAL",
        make: "Fluke",
        model: "550ZE",
        serial_no: "3282801",
        new_id_no: "KTRC-MS-0005",
        shipping_address: { street: "Lab B", line: "Shelf 2" },
        products: [],
        subtotal: 0,
        delivery_fee: 0,
        tax: 0,
        total_amount_due: 0,
    },
    {
        order_id: "KTRC-CAL-EO-053",
        created_at: "1536710400000", // 12/09/2018
        customer: {
            name: "Standard Mega Ohm Box",
        },
        total: 1,
        profit: 0,
        payment_status: "paid",
        order_status: "completed",
        category: "Masters",
        location: "ELECTRO-TECHNICAL",
        make: "Maxwell",
        model: "SRB-12",
        serial_no: "463",
        new_id_no: "KTRC-MS-0035",
        shipping_address: { street: "Lab C", line: "Shelf 3" },
        products: [],
        subtotal: 0,
        delivery_fee: 0,
        tax: 0,
        total_amount_due: 0,
    },
    {
        order_id: "KTRC-CAL-EO-052",
        created_at: "1536710400000", // 12/09/2018
        customer: {
            name: "Standard Resistance Box",
        },
        total: 1,
        profit: 0,
        payment_status: "paid",
        order_status: "completed",
        category: "Masters",
        location: "ELECTRO-TECHNICAL",
        make: "Maxwell",
        model: "SRB-9",
        serial_no: "1409",
        new_id_no: "KTRC-MS-0034",
        shipping_address: { street: "Lab C", line: "Shelf 4" },
        products: [],
        subtotal: 0,
        delivery_fee: 0,
        tax: 0,
        total_amount_due: 0,
    },
    {
        order_id: "KTRC-BM-EO-009",
        created_at: "1599254400000", // 05/09/2020
        customer: {
            name: "Phototherapy Radiometer",
        },
        total: 1,
        profit: 0,
        payment_status: "paid",
        order_status: "completed",
        category: "Masters",
        location: "ELECTRO-TECHNICAL",
        make: "Fluke",
        model: "Dale 40",
        serial_no: "4652010",
        new_id_no: "KTRC-MS-0085",
        shipping_address: { street: "Lab A", line: "Shelf 5" },
        products: [],
        subtotal: 0,
        delivery_fee: 0,
        tax: 0,
        total_amount_due: 0,
    },
    {
        order_id: "KTRC-BM-EO-003",
        created_at: "1599254400000", // 05/09/2020
        customer: {
            name: "Infusion Device Analyser",
        },
        total: 1,
        profit: 0,
        payment_status: "paid",
        order_status: "completed",
        category: "Masters",
        location: "ELECTRO-TECHNICAL",
        make: "Fluke",
        model: "IDA 1S",
        serial_no: "4843781",
        new_id_no: "KTRC-MS-0083",
        shipping_address: { street: "Lab B", line: "Shelf 6" },
        products: [],
        subtotal: 0,
        delivery_fee: 0,
        tax: 0,
        total_amount_due: 0,
    }
];