


export const dummyData = [
  {
    id: 1,
    name: "Type of MSME",
    description: "Small Scale",
  },
  {
    id: 2,
    name: "CIN",
    description: "U73100MP2006PTC019006",
  },
  {
    id: 3,
    name: "Udyam Registration No.",
    description: "UDYAM-MP-23-0012316",
  },
  {
    id: 4,
    name: "MICR CODE",
    description: "452064002",
  },
  {
    id: 5,
    name: "IFSC CODE",
    description: "KKBK0005933",
  },
  {
    id: 6,
    name: "Bank Name",
    description: "Kotak Mahindra Bank Ltd., Indore Branch",
  },
  {
    id: 7,
    name: "Bank Account Type",
    description: "Overdraft Account",
  },
  {
    id: 8,
    name: "Bank Account No.",
    description: "556044016261",
  },
  {
    id: 9,
    name: "PAN",
    description: "AADCK0799A",
  },
  {
    id: 10,
    name: "SAC Code",
    description: "998393",
  },
  {
    id: 11,
    name: "Service Category",
    description: "Scientific and Technical Consultancy",
  },
  {
    id: 12,
    name: "GST No.",
    description: "23AADCK0799A1ZV",
  },
];





